# Student Campus Portal — Public Portfolio Edition

A student-developed, institution-neutral full-stack reference project derived from a real campus-portal design exercise. It is **not an official school service**, is not endorsed by an institution, is not connected to production school infrastructure, and contains no real student, staff, or private data.

This repository also contains a separate read-only presentation of selected, verbatim wording from an earlier portal draft. Source files establish the wording but do not independently establish the authorship of every sentence. See `PROVENANCE.md`. The original drafts remain private and are not included here.

## Public website on GitHub Pages

The free public site is a React/Vite static build. It needs no Express server, PostgreSQL database, login, domain purchase, or environment file.

```sh
npm ci
npm run build:pages
npm run preview:pages -w @portal/web
```

The static build is `apps/web/dist`. It uses hash routes, so a direct link such as `https://<github-username>.github.io/Student-Portal/#/safety` and browser refresh work without server rewrites. The Vite base is `/Student-Portal/`; change that value in `apps/web/vite.config.ts` only if the repository name changes.

After reviewing the exact release candidate and approving publication, push it to the intended public repository. In repository Settings → Pages, select **GitHub Actions** as the build/deployment source. Then run the **Publish read-only portfolio to GitHub Pages** workflow manually from Actions. The workflow does not run automatically on push. The expected free address is `https://<github-username>.github.io/Student-Portal/`.

The public build contains only curated static material. It has no writable Admin screen, reporting form, API calls, session handling, or database data. The campus sketch and daily-life categories illustrate design concepts; they are not real facilities or services. Editorial approval of the recovered health, well-being, and safety passages remains a publication gate.

## Local full-stack engineering prototype

The implementation is a modular monolith: a React/Vite web application, one Node/Express API, shared Zod contracts, and PostgreSQL. Engineering depth comes from database constraints, migrations, server-side authorization, secure sessions, input validation, audit events, tests, and reproducible setup—not from infrastructure count.

### Run locally

Prerequisites: Node.js 22+, npm, and Docker with Compose.

```sh
npm ci
npm run env:init
docker compose up -d
npm run db:migrate
npm run db:seed
npm run demo:user
npm run dev
```

The environment initializer creates local database credentials in an ignored `.env` file and does not print them. The API binds to `127.0.0.1` by default. The demo-user command prompts for a fictional reserved-domain email, a fictional display name, and a hidden password with confirmation. Only a salted password hash is stored in PostgreSQL; no demo password is committed.

Open `http://localhost:5173`. The local frontend binds to `127.0.0.1` and refuses to silently switch ports. Local write mode enables the Admin workspace for accounts carrying the server-verified `content_admin` role. `npm run db:seed` idempotently creates or refreshes the stable fictional seed records without deleting other content. `npm run db:reset -- --confirm-reset=student_campus_portal` clears content, sessions, and audit events, restores the fictional dataset, and preserves locally created user accounts. Reset refuses nonlocal database targets, unexpected database names, and missing or mismatched confirmation.

### Read-only API mode

`PORTAL_WRITE_MODE` defaults to `readonly`. Demo login and every mutation endpoint fail closed in this mode. The API refuses to start with local write mode when `NODE_ENV=production`. A public deployment should use read-only mode and an isolated database containing fictional content only.

## Verification

```sh
npm run verify
npm run build:pages
npm run audit
```

`verify` runs linting, strict type checks, contract/API/frontend tests, production builds, a blocked-identifier/private-path scan, and a Git metadata check. CI also applies migrations, repeated idempotent seeding, and a full reset against a clean PostgreSQL test service.

The project is exercised on macOS with Node 24 and is configured for Linux CI with Node 22 and PostgreSQL 17. The first hosted CI run must pass before publication. Windows has not been tested and is not claimed as a supported environment.

## Deliberate data boundaries

- The local full-stack app's Health & Emergency, Well-being Support, and Community Safety areas are fictional support-directory demonstrations only. The separate static website presents selected historical writing as an intellectual/design archive, not a functioning support service.
- Feedback Forms stores only form metadata: `name`, HTTPS `url`, and `visible`. The portal does not receive, store, proxy, analyze, or integrate form responses.
- No official institutional form URLs are configured. Response ownership, permissions, and retention would remain in the organization-managed form platform.
- The directory, map, events, updates, contacts, and email addresses are fictional and use reserved `.example` domains where relevant.
- Asset records contain metadata and approved HTTPS links; the demo does not implement file upload storage.

## Repository map

- `apps/web` — student-facing UI and local administration UI
- `apps/api` — REST API, authentication, authorization, persistence, and audit logging
- `apps/api/migrations` — PostgreSQL schema and constraints
- `packages/contracts` — shared request schemas and TypeScript contracts
- `scripts` — local environment initialization and public-release checks
- `ARCHITECTURE.md` — trust boundaries and replacement points
- `SECURITY.md` — security controls and production decisions
- `PROVENANCE.md` — source and authorship evidence boundaries
- `.github/workflows/pages.yml` — manually triggered GitHub Pages deployment

This repository intentionally has no institution-specific identity provider, tenant, domain, staff account, reporting route, production credential, internal host, or cloud-provider topology. A real institution must supply and approve those integrations independently.

Before the first commit, inspect the intended public Git author name/email and remote rather than inheriting a personal or institutional identity accidentally. No author metadata, commit, or remote is created by the setup instructions.

Before publishing, choose and add a repository license appropriate to the intended reuse of both code and writing. This package contains no license; if it is merged into a repository that already has one, review that license's scope first. No license is granted by omission in this standalone package. Rights in third-party tooling and any historical source material must be considered separately.
