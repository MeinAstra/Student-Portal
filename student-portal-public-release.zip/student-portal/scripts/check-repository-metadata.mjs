import { spawnSync } from "node:child_process";
import { pathToFileURL } from "node:url";

export function inspectMetadata(run = (args) => spawnSync("git", args, {
  encoding: "utf8", env: { ...process.env, LC_ALL: "C" }, stdio: ["ignore", "pipe", "pipe"]
})) {
  const probe = run(["rev-parse", "--is-inside-work-tree"]);
  if (probe.status === 128 && /not a git repository/i.test(probe.stderr ?? "")) {
    return { status: 0, message: "Repository-metadata check not applicable: no Git repository; history and index were not inspected." };
  }
  if (probe.error || probe.status !== 0 || probe.stdout.trim() !== "true") {
    return { status: 1, message: "Repository-metadata check failed: Git repository inspection unavailable." };
  }
  const git = (args, allowMissing = false) => {
    const result = run(args);
    if (!result.error && allowMissing && result.status === 1 && !result.stdout?.trim() && !result.stderr?.trim()) return "";
    if (result.error || result.status !== 0) throw new Error("Git inspection failed");
    return result.stdout.trim();
  };
  try {
    const findings = [];
    if (git(["config", "--local", "--get", "user.name"], true)) findings.push("repository-local Git author name requires explicit public approval");
    if (git(["config", "--local", "--get", "user.email"], true)) findings.push("repository-local Git author email requires explicit public approval");
    const refs = git(["for-each-ref", "--format=%(refname)"]);
    const allowedPublicEmail = /@(?:example\.(?:com|edu)|[^@]+\.example|users\.noreply\.github\.com)$/i;
    if (refs) {
      for (const email of git(["log", "--all", "--format=%ae%n%ce"]).split("\n").filter(Boolean)) {
        if (!allowedPublicEmail.test(email)) findings.push("Git history contains a non-reserved author or committer email");
      }
    }
    for (const line of git(["remote", "-v"]).split("\n").filter(Boolean)) {
      const url = line.split(/\s+/)[1] ?? "";
      if (/^(?:file:|\/|[A-Z]:\\)/i.test(url) || /https?:\/\/[^/\s]+@/i.test(url)) findings.push("Git remote contains a local path or embedded credentials");
    }
    return findings.length
      ? { status: 1, message: "Repository-metadata check failed:\n" + [...new Set(findings)].join("\n") }
      : { status: 0, message: `Repository-metadata check passed for author configuration, ${refs ? "referenced history identities" : "no existing commit history"}, and remotes. This is not a secret-content scan.` };
  } catch {
    return { status: 1, message: "Repository-metadata check failed: Git inspection incomplete; no clean result can be reported." };
  }
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const result = inspectMetadata();
  (result.status ? console.error : console.log)(result.message);
  process.exitCode = result.status;
}
