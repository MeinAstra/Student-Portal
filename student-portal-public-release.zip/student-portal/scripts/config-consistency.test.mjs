import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const expectedOrigin = "http://localhost:5174";
const manifest = JSON.parse(readFileSync(resolve("package.json"), "utf8"));
const lock = JSON.parse(readFileSync(resolve("package-lock.json"), "utf8"));
assert.equal(manifest.engines.node, "^22.13.0 || ^24.0.0");
assert.equal(lock.packages[""].engines.node, manifest.engines.node);
assert.equal(manifest.name, "student-portal");
assert.equal(manifest.license, "MIT");
assert.equal(lock.packages[""].name, manifest.name);
for (const file of ["docker-compose.yml", ".env.example", "scripts/init-local-env.mjs", "apps/api/src/cli.ts", ".github/workflows/ci.yml"]) {
  const source = readFileSync(resolve(file), "utf8");
  assert.match(source, /student_portal_demo/, `${file} must use the public demo database name`);
  assert.doesNotMatch(source, /i[s]a[_-]/i);
}
const seedSource = readFileSync(resolve("apps/api/src/cli.ts"), "utf8");
const pageSource = readFileSync(resolve("apps/web/src/pages/PublicPages.tsx"), "utf8");
assert.match(seedSource, /Campus Guidelines/);
assert.match(pageSource, /item.category === "Campus Guidelines"/);
assert.match(manifest.scripts["db:reset"], /-w @portal\/api --$/);
assert.match(readFileSync(resolve(".github/workflows/ci.yml"), "utf8"), /db:reset -- --confirm-reset=student_portal_demo_test/);
const files = ["scripts/init-local-env.mjs", ".env.example", "README-FIRST.md", "README.md", ".github/workflows/ci.yml"];
for (const file of files) assert.match(readFileSync(resolve(file), "utf8"), new RegExp(expectedOrigin.replaceAll(".", "\\.")), `${file} must use the documented review Origin`);
const viteConfig = readFileSync(resolve("apps/web/vite.config.ts"), "utf8");
assert.match(viteConfig, /port:\s*5174/);
assert.match(viteConfig, /strictPort:\s*true/);
const serverSource = readFileSync(resolve("apps/api/src/server.ts"), "utf8");
assert.match(serverSource, /await new Promise<void>\(\(resolve, reject\) => server\.close/);
assert.match(serverSource, /finally\s*\{\s*await store\.close\(\)/);
assert.match(serverSource, /process\.once\("SIGINT"/);
assert.match(serverSource, /process\.once\("SIGTERM"/);
