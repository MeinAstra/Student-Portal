import { execFileSync } from "node:child_process";
import { readFileSync, readdirSync } from "node:fs";
import { extname, join, relative, resolve } from "node:path";
import { URL } from "node:url";

const root = resolve(process.argv[2] ?? ".");
const excludedDirectories = new Set(["node_modules", "dist", ".git"]);
const textExtensions = new Set([".ts", ".tsx", ".js", ".mjs", ".json", ".md", ".html", ".css", ".sql", ".yml", ".yaml", ".example"]);
const blockedContent = [
  ["institutional identity", /\bI[S]A\b|i[s]a[_-]portal/i],
  ["vendor-shaped product identifier", /\b[A-Z][A-Za-z]{3,}[0-9]{2,}\b/],
  ["archive reference", /\b[a-z0-9._-]+\.zip\b/i],
  ["tenant configuration", /tenant[_ -]?id\s*[:=]/i],
  ["hidden tool artifact path", /(?:^|[\\/])\.[a-z0-9_-]+[\\/](?:attachments|sessions)[\\/]/i],
  ["temporary capture artifact", /(?:TemporaryItems|screencaptureui|screenshot[ _-]20\d{2})/i],
  ["private absolute path", /(?:\/Users\/[^/\s]+|\/home\/[^/\s]+|[A-Z]:\\Users\\[^\\\s]+)/],
  ["old artifact hash", /\b[a-f0-9]{64}\b/i],
  ["private-key material", /-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/],
  ["credential-shaped assignment", /(?:api[_-]?key|client[_-]?secret|access[_-]?token)\s*[:=]\s*["'](?!YOUR_|<REDACTED>)[^"'\s]+["']/i],
  ["non-loopback network binding", /(?:HOST\s*=\s*0\.0\.0\.0|--host\s+0\.0\.0\.0)/i]
];
const blockedFileNames = /(?:screenshot|\.zip$|\.pem$|\.key$|\.p12$|\.tsbuildinfo$|\.DS_Store$)/i;
const allowedEmail = /@(?:example\.(?:com|edu)|[^@]+\.example)$/i;
const allowedHosts = new Set(["127.0.0.1", "localhost", "example.com", "example.edu", "registry.npmjs.org"]);
const findings = [];

function checkContent(path) {
  const relativePath = relative(root, path);
  if (relativePath === "scripts/check-internal-review.mjs") return;
  const content = readFileSync(path, "utf8");
  for (const [category, pattern] of blockedContent) {
    if (relativePath === "package-lock.json" && category === "vendor-shaped product identifier") continue;
    if (pattern.test(content)) findings.push(`${relativePath}: ${category}`);
  }
  for (const email of content.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi) ?? []) {
    if (!allowedEmail.test(email)) findings.push(`${relativePath}: non-reserved email address`);
  }
  if (relativePath === "package-lock.json") return;
  for (const candidate of content.match(/https:\/\/[a-z0-9.-]+\.[a-z]{2,}[^\s"'`)]+/gi) ?? []) {
    try {
      const hostname = new URL(candidate).hostname.toLowerCase();
      if (!allowedHosts.has(hostname) && !hostname.endsWith(".example")) findings.push(`${relativePath}: unapproved external host`);
    } catch {
      findings.push(`${relativePath}: malformed HTTPS URL literal`);
    }
  }
}

function visit(directory) {
  for (const entry of readdirSync(directory, { withFileTypes: true })) {
    if (excludedDirectories.has(entry.name)) continue;
    const path = join(directory, entry.name);
    const relativePath = relative(root, path);
    if (entry.isDirectory()) visit(path);
    else {
      if (entry.name.startsWith(".env") && entry.name !== ".env.example") continue;
      if (blockedFileNames.test(entry.name)) findings.push(`${relativePath}: blocked review artifact`);
      if (textExtensions.has(extname(entry.name)) || entry.name === ".env.example" || entry.name === "LICENSE") checkContent(path);
    }
  }
}

visit(root);
try {
  const tracked = execFileSync("git", ["ls-files"], { cwd: root, encoding: "utf8", stdio: ["ignore", "pipe", "ignore"] }).split("\n").filter(Boolean);
  for (const path of tracked) {
    if ((/(?:^|\/)\.env[^/]*$/i.test(path) && path !== ".env.example") || /(?:\.tsbuildinfo$|screenshot|\.zip$|\.pem$|\.key$|\.p12$|\.DS_Store$)/i.test(path)) {
      findings.push(`${path}: unsafe tracked metadata or artifact`);
    }
  }
} catch {
  // The content scan remains useful when the internal review folder is not a Git worktree.
}

if (findings.length) {
  console.error("Internal-review safety check failed:\n" + [...new Set(findings)].join("\n"));
  process.exitCode = 1;
} else {
  console.log("Publication safety check passed: no prohibited content matched. This is not a complete secret scan.");
}
