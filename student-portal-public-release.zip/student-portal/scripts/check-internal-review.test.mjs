import assert from "node:assert/strict";
import { execFileSync, spawnSync } from "node:child_process";
import { mkdtempSync, mkdirSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const script = resolve(dirname(fileURLToPath(import.meta.url)), "check-internal-review.mjs");
const fixture = mkdtempSync(resolve(tmpdir(), "portal-review-scan-"));
mkdirSync(resolve(fixture, "src"));
writeFileSync(resolve(fixture, ".env"), "LOCAL_SECRET_IS_NOT_SCANNED=true\n", { mode: 0o600 });
writeFileSync(resolve(fixture, ".env.example"), "API_KEY=YOUR_API_KEY_HERE\n");
writeFileSync(resolve(fixture, "src", "index.ts"), "export const example = true;\n");

execFileSync(process.execPath, [script, fixture], { stdio: "pipe" });

writeFileSync(resolve(fixture, ".DS_Store"), "generated metadata");
const blocked = spawnSync(process.execPath, [script, fixture], { encoding: "utf8" });
assert.notEqual(blocked.status, 0);
assert.match(blocked.stderr, /blocked review artifact/);

// Simulate Git's tracked-file listing without initializing any repository.
const bin = mkdtempSync(resolve(tmpdir(), "portal-review-git-fixture-"));
const git = resolve(bin, "git");
writeFileSync(git, "#!/bin/sh\nprintf '%s\\n' \"$PORTAL_TRACKED_FIXTURE\"\n", { mode: 0o700 });
for (const path of [".env", ".env.local", "apps/api/.env", "apps/api/.env.production", "apps/api/.envrc", "apps/api/.env.example"]) {
  const result = spawnSync(process.execPath, [script, fixture], {
    encoding: "utf8", env: { ...process.env, PATH: bin, PORTAL_TRACKED_FIXTURE: path }
  });
  assert.notEqual(result.status, 0);
  assert.match(result.stderr, /unsafe tracked metadata/);
}
const exampleFixture = mkdtempSync(resolve(tmpdir(), "portal-review-example-"));
writeFileSync(resolve(exampleFixture, ".env.example"), "API_KEY=YOUR_API_KEY_HERE\n");
const example = spawnSync(process.execPath, [script, exampleFixture], {
  encoding: "utf8", env: { ...process.env, PATH: bin, PORTAL_TRACKED_FIXTURE: ".env.example" }
});
assert.equal(example.status, 0, example.stderr);
