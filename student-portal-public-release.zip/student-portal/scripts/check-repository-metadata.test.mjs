import assert from "node:assert/strict";
import test from "node:test";
import { inspectMetadata } from "./check-repository-metadata.mjs";

const ok = (stdout = "") => ({ status: 0, stdout, stderr: "" });
function repository(args) {
  if (args[0] === "rev-parse") return ok("true");
  if (args[0] === "config") return { status: 1, stdout: "", stderr: "" };
  return ok();
}

test("a non-repository is explicitly not applicable, not passed", () => {
  const result = inspectMetadata(() => ({ status: 128, stderr: "fatal: not a git repository" }));
  assert.equal(result.status, 0);
  assert.match(result.message, /not applicable/);
  assert.doesNotMatch(result.message, /passed/);
});

test("missing Git and failed repository inspection fail closed without echoing diagnostics", () => {
  for (const failure of [{ status: null, error: new Error("private detail") }, { status: 128, stderr: "private detail" }]) {
    const result = inspectMetadata(() => failure);
    assert.equal(result.status, 1);
    assert.doesNotMatch(result.message, /private detail/);
  }
  const result = inspectMetadata((args) => args[0] === "remote" ? { status: 128, stderr: "private detail" } : repository(args));
  assert.equal(result.status, 1);
  assert.match(result.message, /incomplete/);
});

test("an unborn repository is valid but does not claim to inspect history", () => {
  const result = inspectMetadata(repository);
  assert.equal(result.status, 0);
  assert.match(result.message, /no existing commit history/);
});

test("history command failure is not treated as empty history", () => {
  const result = inspectMetadata((args) => {
    if (args[0] === "for-each-ref") return ok("refs/heads/main");
    if (args[0] === "log") return { status: 128, stderr: "private detail" };
    return repository(args);
  });
  assert.equal(result.status, 1);
});

test("referenced author and committer identities and remote credentials are screened without disclosure", () => {
  const result = inspectMetadata((args) => {
    if (args[0] === "for-each-ref") return ok("refs/heads/main");
    if (args[0] === "log") return ok("review@example.com\n" + ["private", "invalid.test"].join("@"));
    if (args[0] === "remote") return ok("origin https://synthetic@remote.example/repo (fetch)");
    return repository(args);
  });
  assert.equal(result.status, 1);
  assert.match(result.message, /committer email/);
  assert.match(result.message, /embedded credentials/);
  assert.doesNotMatch(result.message, /private@|synthetic/);
});
