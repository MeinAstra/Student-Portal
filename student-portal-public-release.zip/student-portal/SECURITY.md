# Security Review Notes

## Implemented controls

- Read-only mode by default; production startup rejects local write mode.
- Loopback-only default binding and loopback-only Compose port publishing.
- Interactive local account creation with Bash hidden-input confirmation and salted scrypt hashes; replacing an account revokes its previous sessions.
- Opaque, expiring server sessions stored only as fixed-length hashes.
- HttpOnly/SameSite cookies; Secure cookies in production.
- Exact Origin validation for unsafe requests; per-session CSRF for Admin mutations and active-session logout. Login does not require an existing session.
- Fixed development frontend port with strict startup failure, keeping browser Origin and the API allowlist aligned.
- Server-side `content_admin` checks for every Admin mutation and audit query.
- Strict shared request validation with unknown-field rejection plus PostgreSQL constraints.
- Parameterized SQL and atomic mutation/audit transactions.
- HTTPS-only external URL metadata without embedded credentials.
- Helmet security headers and Content Security Policy; HSTS in production.
- `Cache-Control: no-store` for authentication and Admin responses.
- Rate limits for login and mutations, bounded JSON bodies, explicit malformed/oversized request handling, and generic errors.
- Audit metadata excludes bodies, passwords, cookies, CSRF values, and session tokens.
- Request logs retain generated request IDs, methods, status and route templates, not raw URLs or query strings. Unexpected request failures use a fixed event code and request ID, not raw exception messages.

## Data minimization

Do not place medical histories, counseling information, safeguarding cases, incident reports, feedback responses, student profiles, private notes, or disciplinary records into this application. The support pages are draft directory demonstrations, not operational advice or policy.

The local `.env` contains generated database credentials, is ignored, and is created with mode `0600`. It must never be included in the review ZIP or pasted into tickets/chats. Readiness responses deliberately expose no database connection details.

## Production decisions

- **PRODUCTION INTEGRATION REQUIRED:** school-managed identity and account lifecycle.
- **IT DECISION REQUIRED:** managed secrets, database, TLS, internal hosting, backups, recovery, monitoring, retention, patch ownership, and asset storage.
- **IT DECISION REQUIRED:** approved external-domain allowlist and any multi-instance rate-limit implementation.
- **STAFF CONTENT APPROVAL REQUIRED:** all contacts, service descriptions, maps, documents, updates, events, support content, and Forms links.

This prototype is suitable for internal technical review, not production security acceptance. A production system still requires threat modeling against the chosen infrastructure, security testing, accessibility review, content governance, privacy review, and operational sign-off.
