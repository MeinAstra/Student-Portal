# Local demo operations

Start with [README.md](README.md) for purpose, disclaimer and setup. Everything here operates on fictional demo data, not a school system.

## Optional separate terminals

Run `npm run build -w @portal/contracts` once. Then run `npm run dev -w @portal/api` and `npm run dev -w @portal/web` in separate terminals. Do not also run the combined `npm run dev`.

The frontend is http://localhost:5174; `ALLOWED_ORIGIN` must match exactly. PostgreSQL and API use ports 5432 and 3000. Keep all services on loopback for local writable review.

## Troubleshooting

| Symptom | Check |
|---|---|
| Frontend unavailable | Inspect its terminal; strict port conflicts stop startup. |
| API cannot connect | Check database readiness and migrations; startup fails closed. |
| Liveness 200, readiness 503 | Database connection/schema is unavailable. |
| Database unhealthy | Run `docker compose ps postgres`; do not repeatedly migrate until it is healthy. |
| 401 | Invalid credentials or expired/missing session. |
| 403 | Check role, local write mode, exact Origin and current CSRF state. |
| 400 / 413 | Correct input or reduce request size. |

Use `curl --noproxy '*'` if a local proxy interferes. Never paste environment files or credentials into reports.

## Seed and reset semantics

`npm run db:seed` applies migrations and upserts canonical demo records. It recalculates dates in the configured timezone and overwrites seeded fields; additional rows survive. It is not a harmless read-only startup check.

Reset deletes mutable content, sessions and audit history, then reseeds canonical content. Users and roles survive. Only when deliberately discarding the dedicated demo database:

```sh
npm run db:reset -- --confirm-reset=student_portal_demo
```

Reset requires local write mode, a direct loopback IP (`127.0.0.1` or `::1`), port 5432, no URL query overrides, and database `student_portal_demo` or `student_portal_demo_test`. The confirmation must name that exact database. The connected database name is checked before migration/reset. These checks cannot detect a deliberately configured tunnel or unrelated data stored under an allowed name.

CLI migration, seed and account commands write to the configured database even when API mode is read-only. Never point them at a non-disposable or unrelated database. Migrations are forward-only; no rollback migrations are implemented.

## Stop without deleting data

Press Ctrl+C in the application terminals, then run `docker compose stop postgres`. Inspect owned containers with `docker compose ps -a`. On macOS/Linux, use `lsof -nP -iTCP:3000 -sTCP:LISTEN` and the equivalent for port 5174 to identify listeners.

`docker compose down` removes this project's containers/network but normally preserves named volumes. `docker compose down -v` destroys its volumes and is not routine teardown.

## Verification boundaries

Run integration tests only against a separate disposable database ending in `_test`, with `PORTAL_TEST_DATABASE_URL` supplied securely. Do not use the working demo database. A skipped test is not a runtime pass.

The root `.env.example` is the only approved environment template. Keep all real `.env*`, keys, logs, dumps, cookies, screenshots and local diagnostics outside publication artifacts. Git initialization and publishing are separate, explicit actions.
