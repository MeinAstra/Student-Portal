# Publication verification — 2026-09-29

This is a completed educational/portfolio project, not a production-readiness certificate.

## Automated verification performed

- Clean dependency installation with the included lockfile using `npm ci`.
- `npm run verify`: lint, TypeScript checks, tests, production builds and safety checks passed.
- 66 tests passed; one real PostgreSQL integration test was explicitly skipped.
- Scripted configuration/scanner assertions also passed, including neutral package/database naming, category consistency, environment-file protection and truthful pre-Git metadata reporting.
- Dependency advisory query reported zero known vulnerabilities at verification time. This is time-sensitive and not a security guarantee.

The tests use real HTTP test requests with in-memory stores where applicable. Database-store mocks and frontend source/render tests do not replace real PostgreSQL or user-facing browser verification.

## Unverified checks

- Docker was unavailable, so fresh database startup, migration, seed/reset, database-backed integration, persistence and teardown were not rerun.
- Manual browser smoke testing, keyboard/screen-reader behavior, narrow layouts and multi-tab behavior remain unverified in this publication pass.
- Windows interactive account setup is unverified.
- Git index/history/remote checks are not applicable to this pre-Git export. No repository was initialized or pushed.

These limitations are disclosed rather than treated as passing tests. No non-disposable database was reset, and no existing frontend was stopped or restarted.

## Publication boundary

The distribution includes source, migrations, tests, configuration templates, lockfile, documentation and license. It excludes private environment files, installed dependencies, builds, logs, database exports, credentials and machine-specific artifacts. Only the root `.env.example` is an approved environment template.

All supplied portal records and reserved-domain identities are fictional. Health, Well-being and Community Safety remain placeholders, not professional advice or operational services. A final user-facing browser smoke test and GitHub upload review are separate follow-up steps.
