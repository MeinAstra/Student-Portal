import { useEffect, useRef, useState, type ReactNode } from "react";
import { NavLink } from "react-router-dom";
import type { SessionState } from "@portal/contracts";

const groups = [
  ["Campus", [["Home", "/"], ["Campus Map", "/map"], ["Daily Life Help", "/daily-life"], ["Campus Guidelines", "/regulations"], ["Teacher Contacts", "/directory"]]],
  ["Health & Support", [["Health & Emergency", "/support/health-emergency"], ["Well-being Support", "/support/wellbeing"], ["Community Safety", "/support/community-safety"]]],
  ["Campus Now", [["What’s Changed?", "/updates"], ["Coming Up", "/events"]]],
  ["Contact", [["Contact & Feedback", "/feedback"]]]
] as const;

export const reviewDisclaimer = "EDUCATIONAL PROTOTYPE — FICTIONAL DEMO CONTENT — NOT FOR STUDENT USE";

export function Layout({ children, session }: { children: ReactNode; session: SessionState | null }) {
  const [open, setOpen] = useState(false);
  const menuButton = useRef<HTMLButtonElement>(null);
  const sidebar = useRef<HTMLElement>(null);
  useEffect(() => {
    if (!open) return;
    const focusable = [...(sidebar.current?.querySelectorAll<HTMLElement>('a[href], button:not([disabled])') ?? [])];
    focusable[0]?.focus();
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setOpen(false);
        menuButton.current?.focus();
      } else if (event.key === "Tab" && focusable.length > 0) {
        const first = focusable[0]!;
        const last = focusable.at(-1)!;
        if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
        else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
      }
    };
    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [open]);
  const closeAndRestoreFocus = () => { setOpen(false); menuButton.current?.focus(); };
  return <div className="app-frame">
    <a className="skip-link" href="#main-content">Skip to main content</a>
    {open && <button className="nav-scrim" aria-label="Close navigation" onClick={closeAndRestoreFocus} />}
    <aside ref={sidebar} id="primary-navigation" aria-label="Primary navigation" className={`sidebar ${open ? "sidebar-open" : ""}`}>
      <NavLink to="/" className="brand" onClick={() => setOpen(false)}>
        <span className="brand-mark">SP</span><span>Student Portal</span><small>Educational Demo</small>
      </NavLink>
      <nav>
        {groups.map(([label, links]) => <section className="nav-group" key={label}>
          <h2>{label}</h2>
          {links.map(([name, path]) => <NavLink key={path} to={path} onClick={() => setOpen(false)}>{name}</NavLink>)}
        </section>)}
        <section className="nav-group"><h2>Review</h2><NavLink to="/about" onClick={() => setOpen(false)}>Prototype boundaries</NavLink>{session?.writeMode === "local" && <NavLink to="/admin" onClick={() => setOpen(false)}>Admin Workspace</NavLink>}</section>
      </nav>
      <p className="sidebar-note">Portfolio project · fictional demo data</p>
    </aside>
    <main id="main-content" className="main" tabIndex={-1}>
      <header className="mobile-header"><button ref={menuButton} onClick={() => setOpen(true)} aria-expanded={open} aria-controls="primary-navigation">Menu</button><span>Student Portal</span></header>
      <div className="review-banner">{reviewDisclaimer}</div>
      {children}
    </main>
  </div>;
}
