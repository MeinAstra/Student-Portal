import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";

const pageSource = readFileSync(new URL("./pages/PublicPages.tsx", import.meta.url), "utf8");
const linkSource = readFileSync(new URL("./components/Page.tsx", import.meta.url), "utf8");
const adminSource = readFileSync(new URL("./pages/AdminPage.tsx", import.meta.url), "utf8");
const appSource = readFileSync(new URL("./App.tsx", import.meta.url), "utf8");

test("external links open with opener protections", () => {
  assert.match(linkSource, /target="_blank" rel="noopener noreferrer"/);
});

test("support pages preserve the directory concept without policy or case-data claims", () => {
  assert.match(pageSource, /provides no medical advice or triage/i);
  assert.match(pageSource, /without clinical guidance, confidentiality promises, or case records/i);
  assert.match(pageSource, /not an incident-reporting or safeguarding workflow/i);
  assert.match(pageSource, /DRAFT — NOT SCHOOL POLICY/);
  assert.match(pageSource, /STAFF CONTENT APPROVAL REQUIRED/);
});

test("feedback page states that responses remain outside the portal", () => {
  assert.match(pageSource, /Form responses remain outside this application/);
});

test("broken map images collapse to an availability message", () => {
  assert.match(pageSource, /onError=\{\(\) => setFailed\(true\)\}/);
  assert.match(pageSource, /Configured image is currently unavailable/);
});

test("Admin mutations expose a pending state that disables action buttons", () => {
  assert.match(adminSource, /disabled=\{pending\}/);
  assert.match(adminSource, /aria-busy=\{pending\}/);
});

test("Admin workspace displays governance and integration statuses", () => {
  assert.match(adminSource, /DEMO DATA/);
  assert.match(adminSource, /STAFF CONTENT APPROVAL REQUIRED/);
  assert.match(adminSource, /IT DECISION REQUIRED/);
  assert.match(adminSource, /PRODUCTION INTEGRATION REQUIRED/);
});

test("Admin collection controls and validation errors expose accurate accessibility state", () => {
  assert.doesNotMatch(adminSource, /role="tablist"/);
  assert.match(adminSource, /aria-pressed=\{collection === name\}/);
  assert.match(adminSource, /aria-invalid=\{Boolean\(issue\)\}/);
  assert.match(adminSource, /aria-describedby=\{errorId\}/);
});

test("successful Admin mutations are retained when a follow-up refresh fails", () => {
  assert.match(adminSource, /setRecords\(\(current\).*Promise\.allSettled/s);
  assert.match(adminSource, /Changes were saved, but refreshed data could not be loaded/);
});

test("a portal status identical to the permanent review disclaimer is not rendered twice", () => {
  assert.match(appSource, /content\.portalStatus\.message !== reviewDisclaimer/);
});

test("portal startup failures expose an in-place retry action", () => {
  assert.match(appSource, /void loadPortal\(\)/);
  assert.match(appSource, />Retry<\/button>/);
});

test("Admin record and audit history panels expose truthful loaded empty states", () => {
  assert.match(adminSource, /recordsLoaded && records\.length === 0/);
  assert.match(adminSource, /No demo records exist in this collection/);
  assert.match(adminSource, /loaded && events\.length === 0/);
  assert.match(adminSource, /No audit events have been recorded/);
});

test("Admin deletion names the selected record and audit history is paginated", () => {
  assert.match(adminSource, /Delete the isolated demo record “\$\{label\}”/);
  assert.match(adminSource, /api\.auditEvents\(pageSize, events\.length\)/);
  assert.match(adminSource, />Load more<|"Load more"/);
});

test("public calendar output has machine-readable date semantics", () => {
  assert.match(pageSource, /<time dateTime=\{item\.publishDate\}>/);
  assert.match(pageSource, /<time dateTime=\{item\.date\}>/);
});
