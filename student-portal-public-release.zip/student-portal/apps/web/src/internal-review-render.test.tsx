import assert from "node:assert/strict";
import test from "node:test";
import { renderToStaticMarkup } from "react-dom/server";
import { MemoryRouter, Route, Routes } from "react-router-dom";
import type { PublicContent, SessionState } from "@portal/contracts";
import { Layout } from "./components/Layout.js";
import { EventsPage, HomePage, SupportPage, UpdatesPage } from "./pages/PublicPages.js";

const meta = { id: "10000000-0000-4000-8000-000000000001", createdAt: "2026-01-01T00:00:00.000Z", updatedAt: "2026-01-01T00:00:00.000Z" };
const content: PublicContent = {
  notices: [{ ...meta, title: "Review notice", summary: "Demo data", category: "Review", publishDate: "2026-01-01", expiryDate: "", imageUrl: "", visible: true }],
  events: [], directory: [], resources: [], feedbackForms: [], assets: [], campusMap: null, portalStatus: null,
  support: [{ ...meta, section: "health_emergency", title: "Demo School Health Office — demo placeholder", description: "Directory metadata only.", contactLabel: "STAFF CONTENT APPROVAL REQUIRED", url: "", visible: true }]
};
const session: SessionState = { user: null, csrfToken: null, writeMode: "readonly" };

test("demo shell renders neutral branding, campus navigation, and review warning", () => {
  const markup = renderToStaticMarkup(<MemoryRouter><Layout session={session}><HomePage content={content} /></Layout></MemoryRouter>);
  assert.match(markup, /Student Portal/);
  assert.match(markup, /Educational Demo/);
  assert.match(markup, /NOT FOR STUDENT USE/);
  assert.match(markup, /href="#main-content"/);
  assert.match(markup, /aria-controls="primary-navigation"/);
  assert.match(markup, /aria-expanded="false"/);
  assert.match(markup, /Campus Guidelines/);
  assert.match(markup, /Health &amp; Emergency/);
  assert.match(markup, /does not collect private reports/);
});

test("support route renders draft governance labels and neutral directory content", () => {
  const markup = renderToStaticMarkup(<MemoryRouter initialEntries={["/support/health-emergency"]}><Routes><Route path="/support/:section" element={<SupportPage contacts={content.support} />} /></Routes></MemoryRouter>);
  assert.match(markup, /DRAFT — NOT SCHOOL POLICY/);
  assert.match(markup, /STAFF CONTENT APPROVAL REQUIRED/);
  assert.match(markup, /provides no medical advice or triage/i);
  assert.doesNotMatch(markup, /\b(?:CPR|anaphylaxis|epinephrine|dispatcher)\b/i);
});

test("calendar dates use localized text and machine-readable date semantics", () => {
  const notices = [{ ...meta, title: "Review notice", summary: "Demo data", category: "Review", publishDate: "2026-08-30", expiryDate: "", imageUrl: "", visible: true }];
  const events = [{ ...meta, title: "Review event", description: "Demo data", date: "2026-09-02", location: "", category: "Review", registrationUrl: "", visible: true }];
  const markup = renderToStaticMarkup(<MemoryRouter><UpdatesPage notices={notices} /><EventsPage events={events} /></MemoryRouter>);
  assert.match(markup, /<time dateTime="2026-08-30">[^<]*2026<\/time>/);
  assert.match(markup, /<time dateTime="2026-09-02">[^<]*2026<\/time>/);
  assert.doesNotMatch(markup, /<time>2026-/);
});
