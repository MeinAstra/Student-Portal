import assert from "node:assert/strict";
import test from "node:test";
import { api, ApiError } from "./api.js";

test("API validation failures preserve structured issues for the Admin error summary", async () => {
  const originalFetch = globalThis.fetch;
  globalThis.fetch = async () => new Response(JSON.stringify({
    error: "Validation failed.",
    issues: [{ path: ["url"], message: "URL must use HTTPS." }]
  }), { status: 400, headers: { "Content-Type": "application/json" } });
  try {
    await assert.rejects(api.create("feedbackForms", { name: "Unsafe", url: "javascript:alert(1)", visible: true }, "csrf"), (error: unknown) => {
      assert.equal(error instanceof ApiError, true);
      assert.deepEqual((error as ApiError).issues, [{ path: ["url"], message: "URL must use HTTPS." }]);
      return true;
    });
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test("Admin map loading uses the protected endpoint and retains hidden visibility", async () => {
  const originalFetch = globalThis.fetch;
  globalThis.fetch = async (input) => {
    assert.equal(String(input), "/api/v1/admin/singletons/campusMap");
    return new Response(JSON.stringify({ title: "Hidden map", visible: false }), { status: 200 });
  };
  try { assert.equal((await api.adminCampusMap())?.visible, false); }
  finally { globalThis.fetch = originalFetch; }
});

test("audit history requests carry bounded page coordinates", async () => {
  const originalFetch = globalThis.fetch;
  let requestedPath = "";
  globalThis.fetch = async (input) => {
    requestedPath = String(input);
    return new Response("[]", { status: 200, headers: { "Content-Type": "application/json" } });
  };
  try {
    await api.auditEvents(25, 50);
    assert.equal(requestedPath, "/api/v1/admin/audit-events?limit=25&offset=50");
  } finally {
    globalThis.fetch = originalFetch;
  }
});
