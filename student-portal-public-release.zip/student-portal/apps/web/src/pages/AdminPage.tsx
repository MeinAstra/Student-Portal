import { useEffect, useRef, useState, type FormEvent } from "react";
import type { CollectionName, PublicContent, SessionState } from "@portal/contracts";
import { api, ApiError, type ApiIssue } from "../api.js";
import { Page } from "../components/Page.js";

type Field = { name: string; label: string; type?: "text" | "textarea" | "date" | "url" | "email" | "checkbox" | "select"; options?: string[] };

const fields: Record<CollectionName, Field[]> = {
  notices: [field("title"), field("summary", "Summary", "textarea"), field("category"), field("publishDate", "Publish date", "date"), field("expiryDate", "Expiry date", "date"), field("imageUrl", "Image URL", "url"), field("visible", "Visible", "checkbox")],
  events: [field("title"), field("description", "Description", "textarea"), field("date", "Date", "date"), field("location"), field("category"), field("registrationUrl", "Registration URL", "url"), field("visible", "Visible", "checkbox")],
  directory: [field("name"), field("role"), field("department"), field("email", "Email", "email"), field("location"), field("visible", "Visible", "checkbox")],
  resources: [field("title"), field("description", "Description", "textarea"), field("category"), field("url", "External URL", "url"), field("visible", "Visible", "checkbox")],
  support: [field("section", "Section", "select", ["health_emergency", "wellbeing", "community_safety"]), field("title"), field("description", "Description", "textarea"), field("contactLabel", "Contact label"), field("url", "External URL", "url"), field("visible", "Visible", "checkbox")],
  feedbackForms: [field("name"), field("url", "HTTPS form URL", "url"), field("visible", "Visible", "checkbox")],
  assets: [field("name"), field("url", "HTTPS asset URL", "url"), field("altText", "Alternative text"), field("mediaType", "Media type", "select", ["image", "document"]), field("visible", "Visible", "checkbox")]
};

function field(name: string, label = name[0]!.toUpperCase() + name.slice(1), type: Field["type"] = "text", options?: string[]): Field {
  return options ? { name, label, type, options } : { name, label, type };
}

const labels: Record<CollectionName, string> = { notices: "What’s Changed", events: "Coming Up", directory: "Teacher & Staff Contacts", resources: "Daily Life & Regulations", support: "Health / Well-being / Safety", feedbackForms: "Feedback Forms", assets: "Image & Document Metadata" };
const governance: Record<CollectionName, string> = {
  notices: "DEMO DATA · STAFF CONTENT APPROVAL REQUIRED",
  events: "DEMO DATA · STAFF CONTENT APPROVAL REQUIRED",
  directory: "DEMO DATA · STAFF CONTENT APPROVAL REQUIRED",
  resources: "DEMO DATA · STAFF CONTENT APPROVAL REQUIRED",
  support: "DRAFT — NOT SCHOOL POLICY · STAFF CONTENT APPROVAL REQUIRED",
  feedbackForms: "STAFF CONTENT APPROVAL REQUIRED · PRODUCTION INTEGRATION REQUIRED",
  assets: "IT DECISION REQUIRED · PRODUCTION INTEGRATION REQUIRED"
};

type AdminError = { message: string; issues: ApiIssue[] };

function adminError(reason: unknown): AdminError {
  if (reason instanceof ApiError) return { message: reason.message, issues: reason.issues };
  return { message: reason instanceof Error ? reason.message : "Unexpected request failure.", issues: [] };
}

function ErrorSummary({ error, id = "admin-error-summary" }: { error: AdminError | null; id?: string }) {
  if (!error) return null;
  return <div id={id} className="form-error" role="alert"><p>{error.message}</p>{error.issues.length > 0 && <ul>{error.issues.map((issue, index) => <li key={`${issue.path.join(".")}-${index}`}><strong>{issue.path.join(".") || "Request"}:</strong> {issue.message}</li>)}</ul>}</div>;
}

export function AdminPage({ session, setSession, refreshPublic, content }: { session: SessionState; setSession: (state: SessionState) => void; refreshPublic: () => Promise<void>; content: PublicContent }) {
  if (session.writeMode !== "local") return <Page eyebrow="Administration" title="Read-only internal review" intro="Hosted review deployments intentionally disable demo login and content mutations."><p className="empty">PRODUCTION INTEGRATION REQUIRED — run the isolated local setup with explicitly enabled local write mode to review the CMS flow.</p></Page>;
  if (!session.user) return <Login setSession={setSession} />;
  if (!session.user.roles.includes("content_admin") || !session.csrfToken) return <Page eyebrow="Administration" title="Access denied" intro="A server-verified content_admin role is required."><p className="empty">This account cannot manage content.</p></Page>;
  return <Workspace session={session} setSession={setSession} refreshPublic={refreshPublic} content={content} />;
}

function Login({ setSession }: { setSession: (state: SessionState) => void }) {
  const [error, setError] = useState<AdminError | null>(null);
  const [pending, setPending] = useState(false);
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setError(null); setPending(true);
    const data = new FormData(event.currentTarget);
    try { setSession(await api.login(String(data.get("email")), String(data.get("password")))); }
    catch (reason) { setError(adminError(reason)); }
    finally { setPending(false); }
  }
  return <Page eyebrow="Local CMS demonstration" title="Admin sign in" intro="Use a fictional local account created interactively with the demo-user setup command. No password or credential is included in this repository."><div className="review-labels"><span className="review-label">PRODUCTION INTEGRATION REQUIRED</span><span className="review-label">IT DECISION REQUIRED</span></div><form className="admin-form narrow" aria-busy={pending} onSubmit={submit}><label>Email<input name="email" type="email" autoComplete="username" required /></label><label>Password<input name="password" type="password" minLength={12} autoComplete="current-password" required /></label><ErrorSummary error={error} /><button type="submit" disabled={pending}>{pending ? "Signing in…" : "Sign in"}</button></form></Page>;
}

function Workspace({ session, setSession, refreshPublic, content }: { session: SessionState; setSession: (state: SessionState) => void; refreshPublic: () => Promise<void>; content: PublicContent }) {
  const [collection, setCollection] = useState<CollectionName>("notices");
  const [records, setRecords] = useState<Array<Record<string, unknown>>>([]);
  const [recordsLoaded, setRecordsLoaded] = useState(false);
  const [editing, setEditing] = useState<Record<string, unknown> | null>(null);
  const [error, setError] = useState<AdminError | null>(null);
  const [warning, setWarning] = useState("");
  const [pending, setPending] = useState(false);
  const loadRequest = useRef(0);
  const csrf = session.csrfToken!;
  const load = async () => {
    const requestId = ++loadRequest.current;
    const nextRecords = await api.adminList(collection);
    if (requestId === loadRequest.current) { setRecords(nextRecords); setRecordsLoaded(true); }
  };
  useEffect(() => {
    setEditing(null); setError(null); setWarning(""); setRecords([]); setRecordsLoaded(false);
    load().catch((reason: unknown) => setError(adminError(reason)));
    return () => { loadRequest.current += 1; };
  }, [collection]);

  async function save(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setError(null); setWarning(""); setPending(true);
    const data = new FormData(event.currentTarget);
    const body: Record<string, unknown> = {};
    for (const definition of fields[collection]) body[definition.name] = definition.type === "checkbox" ? data.has(definition.name) : String(data.get(definition.name) ?? "");
    try {
      const editingId = editing?.id ? String(editing.id) : null;
      const saved = editingId ? await api.update(collection, editingId, body, csrf) : await api.create(collection, body, csrf);
      setRecords((current) => editingId ? current.map((record) => String(record.id) === editingId ? saved : record) : [saved, ...current]);
      setEditing(null);
      const refreshed = await Promise.allSettled([load(), refreshPublic()]);
      if (refreshed.some((result) => result.status === "rejected")) setWarning("Changes were saved, but refreshed data could not be loaded. Reload the page before editing again.");
    } catch (reason) { setError(adminError(reason)); }
    finally { setPending(false); }
  }

  async function remove(id: string, label: string) {
    if (!window.confirm(`Delete the isolated demo record “${label}”? This cannot be undone.`)) return;
    setError(null); setWarning(""); setPending(true);
    try {
      await api.remove(collection, id, csrf);
      setRecords((current) => current.filter((record) => String(record.id) !== id));
      setEditing(null);
      const refreshed = await Promise.allSettled([load(), refreshPublic()]);
      if (refreshed.some((result) => result.status === "rejected")) setWarning("The record was deleted, but refreshed data could not be loaded. Reload the page before editing again.");
    }
    catch (reason) { setError(adminError(reason)); }
    finally { setPending(false); }
  }

  async function logout() {
    setPending(true);
    try { await api.logout(csrf); setSession({ user: null, csrfToken: null, writeMode: "local" }); }
    catch (reason) { setError(adminError(reason)); }
    finally { setPending(false); }
  }

  return <Page eyebrow="Local content administration" title="Admin Workspace" intro="Mutations are authorized by the server, validated against shared contracts, committed with audit events, and isolated from production systems.">
    <div className="review-labels"><span className="review-label">DEMO DATA</span><span className="review-label">PRODUCTION INTEGRATION REQUIRED</span></div>
    <div className="admin-heading"><p>Signed in as <strong>{session.user!.displayName}</strong></p><button className="secondary" disabled={pending} onClick={logout}>Sign out</button></div>
    <nav className="admin-tabs" aria-label="Content collection">{(Object.keys(labels) as CollectionName[]).map((name) => <button aria-pressed={collection === name} className={collection === name ? "active" : ""} disabled={pending} key={name} onClick={() => setCollection(name)}>{labels[name]}</button>)}</nav>
    <form className="admin-form" aria-busy={pending} aria-describedby={error ? "admin-error-summary" : undefined} onSubmit={save} key={`${collection}-${String(editing?.id ?? "new")}`}>
      <h2>{editing ? `Edit ${labels[collection]}` : `Add ${labels[collection]}`}</h2>
      <p className="review-label">{governance[collection]}</p>
      <div className="form-grid">{fields[collection].map((definition) => <EditorField key={definition.name} definition={definition} value={editing?.[definition.name]} issues={error?.issues ?? []} />)}</div>
      <ErrorSummary error={error} />
      {warning && <p role="status">{warning}</p>}
      <div className="button-row"><button type="submit" disabled={pending}>{pending ? "Saving…" : editing ? "Save changes" : "Add record"}</button>{editing && <button className="secondary" type="button" disabled={pending} onClick={() => setEditing(null)}>Cancel</button>}</div>
    </form>
    {recordsLoaded && records.length === 0 ? <p className="empty">No demo records exist in this collection.</p> : <div className="record-list">{records.map((record) => {
      const recordLabel = String(record.title ?? record.name ?? record.section ?? "Record");
      return <article key={String(record.id)}><div><strong>{recordLabel}</strong><small>DEMO DATA · {record.visible === false ? "Hidden" : "Visible"}</small><small>{governance[collection]}</small></div><div><button className="secondary" disabled={pending} onClick={() => setEditing(record)}>Edit</button><button className="danger" disabled={pending} onClick={() => remove(String(record.id), recordLabel)}>Delete</button></div></article>;
    })}</div>}
    <Settings content={content} csrf={csrf} refreshPublic={refreshPublic} />
    <AuditPanel />
  </Page>;
}

function EditorField({ definition, value, issues }: { definition: Field; value: unknown; issues: ApiIssue[] }) {
  const issue = issues.find((candidate) => candidate.path[0] === definition.name);
  const errorId = issue ? `${definition.name}-error` : undefined;
  if (definition.type === "checkbox") return <label className="checkbox"><input name={definition.name} type="checkbox" defaultChecked={value === undefined ? true : Boolean(value)} aria-invalid={Boolean(issue)} aria-describedby={errorId} /> {definition.label}{issue && <span id={errorId} className="form-error">{issue.message}</span>}</label>;
  if (definition.type === "textarea") return <label className="wide">{definition.label}<textarea name={definition.name} defaultValue={String(value ?? "")} required aria-invalid={Boolean(issue)} aria-describedby={errorId} />{issue && <span id={errorId} className="form-error">{issue.message}</span>}</label>;
  if (definition.type === "select") return <label>{definition.label}<select name={definition.name} defaultValue={String(value ?? definition.options?.[0] ?? "")} aria-invalid={Boolean(issue)} aria-describedby={errorId}>{definition.options?.map((option) => <option key={option} value={option}>{option.replaceAll("_", " ")}</option>)}</select>{issue && <span id={errorId} className="form-error">{issue.message}</span>}</label>;
  const required = !["expiryDate", "imageUrl", "registrationUrl", "email", "location", "url", "contactLabel"].includes(definition.name);
  return <label>{definition.label}<input name={definition.name} type={definition.type} defaultValue={String(value ?? "")} required={required} aria-invalid={Boolean(issue)} aria-describedby={errorId} />{issue && <span id={errorId} className="form-error">{issue.message}</span>}</label>;
}

function Settings({ content, csrf, refreshPublic }: { content: PublicContent; csrf: string; refreshPublic: () => Promise<void> }) {
  const [message, setMessage] = useState("");
  const [error, setError] = useState<AdminError | null>(null);
  const [pending, setPending] = useState(false);
  const [map, setMap] = useState<PublicContent["campusMap"]>(null);
  const [mapLoaded, setMapLoaded] = useState(false);
  useEffect(() => {
    let active = true;
    setMapLoaded(false);
    void api.adminCampusMap().then((value) => {
      if (active) { setMap(value); setMapLoaded(true); }
    }).catch((reason: unknown) => { if (active) setError(adminError(reason)); });
    return () => { active = false; };
  }, [csrf]);
  async function refreshAfterSave(success: string) {
    try { await refreshPublic(); setMessage(success); }
    catch { setMessage(`${success} Refreshed public content could not be loaded; reload the page before editing again.`); }
  }
  async function saveMap(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setPending(true); setError(null); setMessage(""); const data = new FormData(event.currentTarget);
    try { await api.updateSingleton("campusMap", { title: String(data.get("title")), description: String(data.get("description")), imageUrl: String(data.get("imageUrl")), visible: data.has("visible") }, csrf); await refreshAfterSave("Map settings saved."); }
    catch (reason) { setError(adminError(reason)); }
    finally { setPending(false); }
  }
  async function saveStatus(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setPending(true); setError(null); setMessage(""); const data = new FormData(event.currentTarget);
    try { await api.updateSingleton("portalStatus", { message: String(data.get("message")) }, csrf); await refreshAfterSave("Portal status saved."); }
    catch (reason) { setError(adminError(reason)); }
    finally { setPending(false); }
  }
  return <section className="settings"><h2>Campus Map & Portal Status</h2><div className="review-labels"><span className="review-label">STAFF CONTENT APPROVAL REQUIRED</span><span className="review-label">IT DECISION REQUIRED</span></div>{message && <p role="status">{message}</p>}<ErrorSummary error={error} />{mapLoaded ? <form className="admin-form" aria-busy={pending} onSubmit={saveMap}><h3>Campus map</h3><label>Title<input name="title" defaultValue={map?.title ?? ""} required /></label><label className="wide">Description<textarea name="description" defaultValue={map?.description ?? ""} required /></label><label>HTTPS image URL<input name="imageUrl" type="url" defaultValue={map?.imageUrl ?? ""} /></label><label className="checkbox"><input name="visible" type="checkbox" defaultChecked={map?.visible ?? true} /> Visible</label><button disabled={pending}>Save map</button></form> : <p role="status">{error ? "Map settings could not be loaded. Reload the page to retry." : "Loading map settings…"}</p>}<form className="admin-form" aria-busy={pending} onSubmit={saveStatus}><h3>Portal status</h3><label className="wide">Message<input name="message" maxLength={300} defaultValue={content.portalStatus?.message ?? ""} /></label><button disabled={pending}>Save status</button></form></section>;
}

function AuditPanel() {
  const pageSize = 25;
  const [events, setEvents] = useState<Array<Record<string, unknown>>>([]);
  const [error, setError] = useState("");
  const [pending, setPending] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  async function load() {
    setPending(true);
    try {
      const nextEvents = await api.auditEvents(pageSize, events.length);
      setEvents((current) => [...current, ...nextEvents]);
      setLoaded(true);
      setHasMore(nextEvents.length === pageSize);
      setError("");
    } catch (reason) { setError(reason instanceof Error ? reason.message : "Unexpected request failure."); }
    finally { setPending(false); }
  }
  return <section className="settings"><div className="admin-heading"><div><h2>Audit events</h2><p>Recent mutation metadata; request bodies and credentials are never included.</p></div>{hasMore && <button className="secondary" disabled={pending} onClick={load}>{pending ? "Loading…" : loaded ? "Load more" : "Load recent events"}</button>}</div>{error && <p className="form-error" role="alert">{error}</p>}{loaded && events.length === 0 ? <p className="empty">No audit events have been recorded.</p> : <div className="record-list">{events.map((event) => <article key={String(event.id ?? event.requestId)}><div><strong>{String(event.action)} · {String(event.entityType)}</strong><small>{String(event.occurredAt ?? "Current test session")}</small></div><code>{String(event.entityId)}</code></article>)}</div>}{loaded && !hasMore && events.length > 0 && <p className="empty">All available audit events are shown.</p>}</section>;
}
