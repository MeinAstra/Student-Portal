import { useState } from "react";
import { Link, useParams } from "react-router-dom";
import type { DirectoryEntryInput, EventInput, FeedbackFormInput, NoticeInput, PublicContent, RecordWithMeta, ResourceInput, SupportContactInput } from "@portal/contracts";
import { Empty, ExternalLink, Page } from "../components/Page.js";

type MapRecord = PublicContent["campusMap"];
type ResourceMode = "daily-life" | "regulations";

function ReviewLabels({ labels }: { labels: string[] }) {
  return <div className="review-labels" aria-label="Review status">{labels.map((label) => <span className="review-label" key={label}>{label}</span>)}</div>;
}

function formatCalendarDate(value: string) {
  const [year, month, day] = value.split("-").map(Number);
  return new Intl.DateTimeFormat(undefined, { year: "numeric", month: "long", day: "numeric", timeZone: "UTC" }).format(new Date(Date.UTC(year!, month! - 1, day!)));
}

export function HomePage({ content }: { content: PublicContent }) {
  const notice = content.notices[0];
  return <Page eyebrow="Demo School campus overview" title="Explore a fictional campus." intro="An educational full-stack demonstration of fictional campus information, services, updates and content administration.">
    <ReviewLabels labels={["DEMO DATA", "PRODUCTION INTEGRATION REQUIRED"]} />
    <div className="home-grid"><section className="feature"><p className="eyebrow">What’s Changed?</p>{notice ? <><h2>{notice.title}</h2><p>{notice.summary}</p><Link className="text-link" to="/updates">All changes →</Link></> : <Empty>No current updates are published.</Empty>}</section>
    <section><p className="eyebrow">Start here</p><div className="quick-links">{([["Campus Map", "/map"], ["Health & Emergency", "/support/health-emergency"], ["Well-being Support", "/support/wellbeing"], ["Teacher Contacts", "/directory"]] as const).map(([name, path]) => <Link key={path} to={path}>{name}<span>→</span></Link>)}</div></section></div>
    <div className="privacy-statement"><p className="eyebrow">Data minimization</p><h2>This prototype stores service-directory content. It does not collect private reports, medical records, counseling records, or support cases.</h2></div>
  </Page>;
}

export function MapPage({ map }: { map: MapRecord }) {
  return <Page eyebrow="Demo School campus" title="Campus Map" intro="A configurable area for a future staff-approved campus map and service locations."><ReviewLabels labels={["DEMO DATA", "STAFF CONTENT APPROVAL REQUIRED"]} />{!map ? <Empty>No map is configured.</Empty> : <article className="map-card"><div className="map-placeholder" aria-hidden="true"><span>Building placeholder</span><span>Service placeholder</span><span>Entrance placeholder</span></div><div><h2>{map.title}</h2><p>{map.description}</p>{map.imageUrl && <SafeImage key={map.imageUrl} src={map.imageUrl} alt={map.title} />}</div></article>}</Page>;
}

function SafeImage({ src, alt }: { src: string; alt: string }) {
  const [failed, setFailed] = useState(false);
  return failed ? <p className="image-unavailable" role="status">Configured image is currently unavailable.</p> : <img src={src} alt={alt} onError={() => setFailed(true)} />;
}

export function ResourcesPage({ resources, mode }: { resources: Array<RecordWithMeta<ResourceInput>>; mode: ResourceMode }) {
  const regulations = mode === "regulations";
  const matching = resources.filter((item) => regulations ? item.category === "Campus Guidelines" : item.category !== "Campus Guidelines");
  return <Page eyebrow={regulations ? "Reference library" : "Practical guide"} title={regulations ? "Campus Guidelines" : "Daily Life Help"} intro={regulations ? "Fictional document metadata for demonstration; this is not school policy." : "Fictional campus-service examples for software demonstration."}><ReviewLabels labels={["DEMO DATA", "STAFF CONTENT APPROVAL REQUIRED"]} /><CardList records={matching} render={(item) => <><p className="eyebrow">{item.category}</p><h2>{item.title}</h2><p>{item.description}</p>{item.url && <ExternalLink href={item.url}>Open approved resource</ExternalLink>}</>} /></Page>;
}

export function DirectoryPage({ entries }: { entries: Array<RecordWithMeta<DirectoryEntryInput>> }) {
  return <Page eyebrow="Campus directory" title="Teacher Contacts" intro="Role-based demonstration records showing how staff-approved contact information could be organized."><ReviewLabels labels={["DEMO DATA", "STAFF CONTENT APPROVAL REQUIRED"]} /><CardList records={entries} render={(item) => <><p className="eyebrow">{item.department}</p><h2>{item.name}</h2><p>{item.role}</p>{item.location && <p>{item.location}</p>}{item.email && <a className="text-link" href={`mailto:${item.email}`}>{item.email}</a>}</>} /></Page>;
}

const supportSections = {
  "health-emergency": ["health_emergency", "Health & Emergency", "A directory model for future school-approved health and emergency contacts. It provides no medical advice or triage."],
  wellbeing: ["wellbeing", "Well-being Support", "A directory model for future school-approved support contacts, without clinical guidance, confidentiality promises, or case records."],
  "community-safety": ["community_safety", "Community Safety", "A directory model for future school-approved safety resources. It is not an incident-reporting or safeguarding workflow."]
} as const;

export function SupportPage({ contacts }: { contacts: Array<RecordWithMeta<SupportContactInput>> }) {
  const { section = "" } = useParams();
  const details = supportSections[section as keyof typeof supportSections];
  if (!details) return <NavigateSupport />;
  const [key, title, intro] = details;
  const matching = contacts.filter((item) => item.section === key);
  return <Page eyebrow="Health & support directory" title={title} intro={intro}><ReviewLabels labels={["DRAFT — NOT SCHOOL POLICY", "STAFF CONTENT APPROVAL REQUIRED"]} /><div className="demo-caution"><strong>Demonstration boundary:</strong> entries are fictional placeholders. These examples are not operational contacts, advice or reporting routes.</div><CardList records={matching} render={(item) => <><h2>{item.title}</h2><p>{item.description}</p>{item.contactLabel && <p className="contact-label">{item.contactLabel}</p>}{item.url && <ExternalLink href={item.url}>Open approved resource</ExternalLink>}</>} /></Page>;
}

function NavigateSupport() { return <Page eyebrow="Health & support" title="Directory entry not found" intro="Choose a support section from the navigation."><Empty>No matching section exists.</Empty></Page>; }

export function UpdatesPage({ notices }: { notices: Array<RecordWithMeta<NoticeInput>> }) {
  return <Page eyebrow="Campus Now" title="What’s Changed?" intro="Current notices are filtered by server-enforced visibility, publish date, and expiry date."><ReviewLabels labels={["DEMO DATA"]} /><div className="editorial-list">{notices.length ? notices.map((item) => <article key={item.id}><div><time dateTime={item.publishDate}>{formatCalendarDate(item.publishDate)}</time><span>{item.category}</span></div><div><h2>{item.title}</h2><p>{item.summary}</p></div></article>) : <Empty>No current updates are published.</Empty>}</div></Page>;
}

export function EventsPage({ events }: { events: Array<RecordWithMeta<EventInput>> }) {
  return <Page eyebrow="Campus Now" title="Coming Up" intro="A concise calendar model for future school-approved activities."><ReviewLabels labels={["DEMO DATA"]} /><div className="editorial-list">{events.length ? events.map((item) => <article key={item.id}><div><time dateTime={item.date}>{formatCalendarDate(item.date)}</time><span>{item.category}</span></div><div><h2>{item.title}</h2><p>{item.description}</p><p>{item.location}</p>{item.registrationUrl && <ExternalLink href={item.registrationUrl}>Registration information</ExternalLink>}</div></article>) : <Empty>No upcoming events are published.</Empty>}</div></Page>;
}

export function FeedbackPage({ forms }: { forms: Array<RecordWithMeta<FeedbackFormInput>> }) {
  return <Page eyebrow="Demonstration links" title="Contact & Feedback" intro="The portal stores and displays only form names, approved HTTPS links, and visibility. Form responses remain outside this application."><ReviewLabels labels={["STAFF CONTENT APPROVAL REQUIRED", "PRODUCTION INTEGRATION REQUIRED"]} /><div className="link-list">{forms.length ? forms.map((form) => <ExternalLink key={form.id} href={form.url}>{form.name}</ExternalLink>) : <Empty>No approved feedback Forms are currently configured.</Empty>}</div></Page>;
}

export function AboutPage() {
  return <Page eyebrow="Educational portfolio project" title="Prototype boundaries" intro="A completed educational portfolio project demonstrating a student portal for a fictional campus; not affiliated with any school."><div className="prose"><h2>What already works</h2><p>The prototype includes a React frontend, Node REST API, PostgreSQL migrations and constraints, server-managed sessions, server-side roles, CSRF and Origin checks, strict validation, audit events, security headers, rate limits, tests, and repeatable local setup.</p><h2>What is simulated</h2><p>All users, contacts, events, service information, map metadata, and links are demonstration or draft content. Local credentials exist only when a reviewer creates them interactively.</p><h2>What needs staff approval</h2><p>Health, well-being, community-safety, staff-directory, policy, map, event, update, and feedback-link content must be governed and approved by responsible operators before any real deployment.</p><h2>What needs IT integration</h2><p>Production identity, managed PostgreSQL, secrets, TLS, hosting, monitoring, backups, asset storage, domain allowlists, and operational ownership remain IT decisions. No school tenant or live infrastructure is connected.</p><h2>Data boundary</h2><p>The portal stores service content, not medical records, counseling notes, safeguarding cases, incident reports, feedback responses, student profiles, private staff notes, or disciplinary records.</p></div></Page>;
}

function CardList<T extends { id: string }>({ records, render }: { records: T[]; render: (item: T) => React.ReactNode }) {
  return records.length ? <div className="card-grid">{records.map((item) => <article className="card" key={item.id}>{render(item)}</article>)}</div> : <Empty>No entries are currently available.</Empty>;
}
