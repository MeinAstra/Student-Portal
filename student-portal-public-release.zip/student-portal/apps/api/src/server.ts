import { createApp } from "./app.js";
import { loadConfig } from "./config.js";
import { PgStore } from "./pg-store.js";

const config = loadConfig();
const store = new PgStore(config.databaseUrl);
await store.readiness().catch(async () => {
  await store.close();
  throw new Error("Database is not ready. Start PostgreSQL and run npm run db:migrate before starting the portal.");
});
const server = createApp(store, config).listen(config.port, config.host, () => console.log(`Campus portal API listening on http://${config.host}:${config.port} in ${config.writeMode} mode.`));

let shuttingDown = false;
async function shutdown() {
  if (shuttingDown) return;
  shuttingDown = true;
  try {
    await new Promise<void>((resolve, reject) => server.close((error) => error ? reject(error) : resolve()));
  } finally {
    await store.close();
  }
}
function handleSignal() {
  void shutdown().catch((error: unknown) => {
    console.error(error instanceof Error ? error.message : "Graceful shutdown failed.");
    process.exitCode = 1;
  });
}
process.once("SIGINT", handleSignal);
process.once("SIGTERM", handleSignal);
