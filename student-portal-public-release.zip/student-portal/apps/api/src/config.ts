import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { config as loadEnvironment } from "dotenv";

loadEnvironment({ path: resolve(dirname(fileURLToPath(import.meta.url)), "../../../.env"), quiet: true });

export interface Config {
  databaseUrl: string;
  host: string;
  port: number;
  writeMode: "readonly" | "local";
  secureCookie: boolean;
  allowedOrigin: string;
  institutionTimeZone: string;
  nodeEnv: string;
}

export function loadConfig(environment: NodeJS.ProcessEnv = process.env): Config {
  const writeMode = environment.PORTAL_WRITE_MODE === "local" ? "local" : "readonly";
  const nodeEnv = (environment.NODE_ENV ?? "development").trim().toLowerCase();
  const host = environment.HOST?.trim() || "127.0.0.1";
  const port = Number(environment.PORT ?? 3000);
  const allowedOrigin = environment.ALLOWED_ORIGIN?.trim() || "http://localhost:5174";
  const institutionTimeZone = environment.INSTITUTION_TIME_ZONE?.trim() || "Asia/Shanghai";
  if (nodeEnv === "production" && writeMode === "local") {
    throw new Error("Production startup refused: PORTAL_WRITE_MODE must remain readonly.");
  }
  if (!Number.isInteger(port) || port < 1 || port > 65_535) throw new Error("PORT must be an integer between 1 and 65535.");
  if (writeMode === "local" && !["127.0.0.1", "::1", "localhost"].includes(host)) throw new Error("Local write mode must bind to a loopback host: 127.0.0.1, ::1, or localhost.");
  try {
    const origin = new URL(allowedOrigin);
    if (!origin.protocol.startsWith("http") || origin.origin !== allowedOrigin) throw new Error();
  } catch {
    throw new Error("ALLOWED_ORIGIN must be one exact HTTP(S) origin without a path.");
  }
  try { new Intl.DateTimeFormat("en", { timeZone: institutionTimeZone }).format(); }
  catch { throw new Error("INSTITUTION_TIME_ZONE must be a valid IANA time zone."); }
  return {
    databaseUrl: environment.DATABASE_URL ?? "",
    host,
    port,
    writeMode,
    secureCookie: environment.SESSION_COOKIE_SECURE === "true" || nodeEnv === "production",
    allowedOrigin,
    institutionTimeZone,
    nodeEnv
  };
}
