import assert from "node:assert/strict";
import { randomBytes, randomUUID } from "node:crypto";
import test from "node:test";
import request from "supertest";
import type { CollectionName, PublicContent, Role } from "@portal/contracts";
import { createApp } from "../src/app.js";
import { hashPassword, sha256 } from "../src/security.js";
import type { AuditContext, AuthUser, SessionRecord, Store } from "../src/store.js";

const origin = "http://localhost:5174";
const adminId = "10000000-0000-4000-8000-000000000001";
const viewerId = "10000000-0000-4000-8000-000000000002";
const password = randomBytes(24).toString("base64url");

class MemoryStore implements Store {
  users = new Map<string, AuthUser>();
  sessions = new Map<string, SessionRecord>();
  records = new Map<CollectionName, Array<Record<string, unknown>>>();
  audits: Array<{ action: string; entityType: string; entityId: string }> = [];
  ready = true;
  lastPublicDate = "";

  constructor() {
    this.users.set("admin@campus.example", { id: adminId, email: "admin@campus.example", displayName: "Demo Admin", passwordHash: hashPassword(password), roles: ["viewer", "content_admin"], active: true });
    this.users.set("viewer@campus.example", { id: viewerId, email: "viewer@campus.example", displayName: "Demo Viewer", passwordHash: hashPassword(password), roles: ["viewer"], active: true });
  }
  async readiness() { if (!this.ready) throw new Error("not ready"); }
  async adminCampusMap(): Promise<PublicContent["campusMap"]> {
    return { id: adminId, title: "Hidden map", description: "Draft", imageUrl: "", visible: false, createdAt: "", updatedAt: "" };
  }
  async publicContent(today: string): Promise<PublicContent> { this.lastPublicDate = today; return { notices: [], events: [], directory: [], resources: [], support: [], feedbackForms: [], assets: [], campusMap: null, portalStatus: null }; }
  async list(collection: CollectionName) { return this.records.get(collection) ?? []; }
  async create(collection: CollectionName, input: Record<string, unknown>, audit: AuditContext) {
    const record = { ...input, id: randomUUID(), createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() };
    this.records.set(collection, [...(this.records.get(collection) ?? []), record]); this.audits.push({ ...audit, entityId: String(record.id) }); return record;
  }
  async update(collection: CollectionName, id: string, input: Record<string, unknown>, audit: AuditContext) {
    const existing = (this.records.get(collection) ?? []).find((item) => item.id === id);
    if (!existing) return null;
    Object.assign(existing, input); this.audits.push({ ...audit, entityId: id }); return existing;
  }
  async remove(collection: CollectionName, id: string, audit: AuditContext) {
    const records = this.records.get(collection) ?? [];
    const removed = records.some((item) => item.id === id); this.records.set(collection, records.filter((item) => item.id !== id));
    if (removed) this.audits.push({ ...audit, entityId: id }); return removed;
  }
  async updateSingleton(_name: "campusMap" | "portalStatus", input: Record<string, unknown>, audit: AuditContext) { const record = { id: "30000000-0000-4000-8000-000000000001", ...input }; this.audits.push({ ...audit, entityId: String(record.id) }); return record; }
  async findUserByEmail(email: string) { return this.users.get(email) ?? null; }
  async createUser(input: { email: string; displayName: string; passwordHash: string; roles: Role[] }) { this.users.set(input.email, { id: adminId, active: true, ...input }); }
  async createSession(input: { idHash: string; userId: string; csrfHash: string; expiresAt: Date }) {
    const user = [...this.users.values()].find((candidate) => candidate.id === input.userId)!;
    this.sessions.set(input.idHash, { user: { id: user.id, email: user.email, displayName: user.displayName, roles: user.roles }, csrfHash: input.csrfHash, expiresAt: input.expiresAt });
  }
  async getSession(idHash: string) {
    const session = this.sessions.get(idHash);
    return session && session.expiresAt > new Date() ? session : null;
  }
  async deleteSession(idHash: string) { this.sessions.delete(idHash); }
  async listAuditEvents(limit: number, offset: number) { return this.audits.slice().reverse().slice(offset, offset + limit); }
  async close() {}
}

function config(writeMode: "readonly" | "local" = "local") {
  return { databaseUrl: "unused", host: "127.0.0.1", port: 3000, writeMode, secureCookie: false, allowedOrigin: origin, institutionTimeZone: "Asia/Shanghai", nodeEnv: "test" } as const;
}

async function login(agent: ReturnType<typeof request.agent>, email = "admin@campus.example") {
  const response = await agent.post("/api/v1/auth/login").set("Origin", origin).send({ email, password });
  assert.equal(response.status, 200);
  assert.equal(response.body.user.email, email);
  return response.body.csrfToken as string;
}

test("public content is available without a session", async () => {
  const response = await request(createApp(new MemoryStore(), config())).get("/api/v1/content");
  assert.equal(response.status, 200);
  assert.deepEqual(response.body.feedbackForms, []);
  assert.match(String(response.headers["content-security-policy"]), /frame-ancestors 'none'/);
  assert.doesNotMatch(String(response.headers["content-security-policy"]), /img-src[^;]*data:/);
  assert.equal(response.headers["permissions-policy"], "camera=(), microphone=(), geolocation=()");
  assert.equal(response.headers["strict-transport-security"], undefined);
});

test("readiness bypasses failed session lookup with both healthy and unavailable storage", async () => {
  const store = new MemoryStore();
  store.getSession = async () => { throw new Error("must not look up session"); };
  const app = createApp(store, config());
  for (const path of ["/api/v1/health", "/api/v1/health/ready"]) {
    assert.equal((await request(app).get(path).set("Cookie", "portal_session=synthetic")).status, 200);
    store.ready = false;
    assert.equal((await request(app).get(path).set("Cookie", "portal_session=synthetic")).status, 503);
    store.ready = true;
  }
});

test("hidden map settings require local Admin access and remain absent from public content", async () => {
  const app = createApp(new MemoryStore(), config());
  const path = "/api/v1/admin/singletons/campusMap";
  assert.equal((await request(app).get(path)).status, 401);
  const viewer = request.agent(app);
  await login(viewer, "viewer@campus.example");
  assert.equal((await viewer.get(path)).status, 403);
  const admin = request.agent(app);
  await login(admin);
  const map = await admin.get(path);
  assert.equal(map.status, 200);
  assert.equal(map.body.visible, false);
  assert.equal(map.body.title, "Hidden map");
  assert.equal((await admin.get("/api/v1/content")).body.campusMap, null);
  assert.equal(map.headers["cache-control"], "no-store");
  const readonlyStore = new MemoryStore();
  const user = readonlyStore.users.get("admin@campus.example")!;
  readonlyStore.sessions.set(sha256("synthetic-readonly-session"), {
    user, csrfHash: sha256("synthetic-csrf"), expiresAt: new Date(Date.now() + 60_000)
  });
  assert.equal((await request(createApp(readonlyStore, config("readonly"))).get(path)
    .set("Cookie", "portal_session=synthetic-readonly-session")).status, 403);
});

test("request logs keep correlation IDs but omit raw paths, bodies, cookies and exception detail", async () => {
  const store = new MemoryStore();
  store.publicContent = async () => { throw new Error("synthetic-private-diagnostic"); };
  const logs: string[] = [];
  const info = console.info;
  const error = console.error;
  console.info = (...values: unknown[]) => { logs.push(values.join(" ")); };
  console.error = (...values: unknown[]) => { logs.push(values.join(" ")); };
  try {
    const app = createApp(store, config());
    const response = await request(app).get("/api/v1/content?synthetic-private-query")
      .set("Cookie", "unrelated=synthetic-private-cookie");
    assert.equal(response.status, 500);
    assert.deepEqual(response.body, { error: "Unexpected server error." });
    await request(app).get("/synthetic-private-path");
    await request(app).post("/api/v1/auth/login").set("Origin", origin)
      .send({ email: "admin@campus.example", password: "synthetic-private-password" });
    assert.doesNotMatch(logs.join("\n"), /synthetic-private/);
    const events = logs.map((line) => JSON.parse(line) as { requestId: string; event?: string; route: string });
    assert.ok(events.some((event) => event.event === "request_failed" && event.requestId === response.headers["x-request-id"]));
    assert.ok(events.some((event) => event.route === "unmatched"));
    assert.ok(events.some((event) => event.route === "/api/v1/content"));
  } finally { console.info = info; console.error = error; }
});

test("public date filtering uses the configured institution date around UTC midnight", async () => {
  const store = new MemoryStore();
  const instant = new Date("2026-08-29T18:30:00.000Z");
  const response = await request(createApp(store, config(), () => instant)).get("/api/v1/content");
  assert.equal(response.status, 200);
  assert.equal(store.lastPublicDate, "2026-08-30");
});

test("readiness checks database state while liveness remains process-only", async () => {
  const store = new MemoryStore();
  store.ready = false;
  const app = createApp(store, config());
  assert.equal((await request(app).get("/api/v1/health/live")).status, 200);
  const health = await request(app).get("/api/v1/health");
  assert.equal(health.status, 503);
  assert.deepEqual(health.body, { status: "not_ready", writeMode: "local" });
  assert.equal((await request(app).get("/api/v1/health/ready")).status, 503);
});

test("liveness bypasses session storage and auth errors remain non-cacheable", async () => {
  const store = new MemoryStore();
  store.getSession = async () => { throw new Error("Session storage unavailable"); };
  const app = createApp(store, config());
  const live = await request(app).get("/api/v1/health/live").set("Cookie", "portal_session=unavailable");
  assert.equal(live.status, 200);
  const rejected = await request(app).post("/api/v1/auth/login").set("Origin", "https://rejected.example");
  assert.equal(rejected.status, 403);
  assert.equal(rejected.headers["cache-control"], "no-store");
});

test("production headers enable HSTS while production remains read-only", async () => {
  const response = await request(createApp(new MemoryStore(), { ...config("readonly"), nodeEnv: "production", secureCookie: true })).get("/api/v1/health");
  assert.equal(response.status, 200);
  assert.match(String(response.headers["strict-transport-security"]), /max-age=31536000/);
});

test("read-only mode fails closed for demo login", async () => {
  const store = new MemoryStore();
  const response = await request(createApp(store, config("readonly"))).post("/api/v1/auth/login").set("Origin", origin).send({ email: "admin@campus.example", password });
  assert.equal(response.status, 403);
  const user = store.users.get("admin@campus.example")!;
  store.sessions.set(sha256("existing-session"), { user: { id: user.id, email: user.email, displayName: user.displayName, roles: user.roles }, csrfHash: sha256("csrf"), expiresAt: new Date(Date.now() + 60_000) });
  const hiddenAdminData = await request(createApp(store, config("readonly"))).get("/api/v1/admin/notices").set("Cookie", "portal_session=existing-session");
  assert.equal(hiddenAdminData.status, 403);
});

test("admin mutations require authentication, role, origin, and CSRF", async () => {
  const store = new MemoryStore();
  const app = createApp(store, config());
  const unauthenticated = await request(app).post("/api/v1/admin/feedbackForms").set("Origin", origin).send({ name: "General feedback", url: "https://forms.example/general", visible: true });
  assert.equal(unauthenticated.status, 401);

  const viewer = request.agent(app);
  const viewerCsrf = await login(viewer, "viewer@campus.example");
  const forbidden = await viewer.post("/api/v1/admin/feedbackForms").set("Origin", origin).set("X-CSRF-Token", viewerCsrf).send({ name: "General feedback", url: "https://forms.example/general", visible: true });
  assert.equal(forbidden.status, 403);

  const admin = request.agent(app);
  await login(admin);
  const missingCsrf = await admin.post("/api/v1/admin/feedbackForms").set("Origin", origin).send({ name: "General feedback", url: "https://forms.example/general", visible: true });
  assert.equal(missingCsrf.status, 403);
  const wrongOrigin = await admin.post("/api/v1/admin/feedbackForms").set("Origin", "https://attacker.example").send({ name: "General feedback", url: "https://forms.example/general", visible: true });
  assert.equal(wrongOrigin.status, 403);
});

test("expired, malformed, and client-forged sessions cannot reach Admin data", async () => {
  const store = new MemoryStore();
  const user = store.users.get("admin@campus.example")!;
  store.sessions.set(sha256("expired"), { user: { id: user.id, email: user.email, displayName: user.displayName, roles: user.roles }, csrfHash: sha256("csrf"), expiresAt: new Date(Date.now() - 1) });
  const app = createApp(store, config());
  const expired = await request(app).get("/api/v1/admin/notices").set("Cookie", "portal_session=expired");
  assert.equal(expired.status, 401);
  const malformed = await request(app).get("/api/v1/admin/notices").set("Cookie", "portal_session=%E0%A4%A");
  assert.equal(malformed.status, 401);
  const forged = await request(app).get("/api/v1/admin/notices").set("Cookie", `portal_session=${Buffer.from(JSON.stringify({ roles: ["content_admin"] })).toString("base64url")}`);
  assert.equal(forged.status, 401);
});

test("malformed, oversized, and unknown API requests fail with bounded responses", async () => {
  const app = createApp(new MemoryStore(), config());
  const malformed = await request(app).post("/api/v1/auth/login").set("Origin", origin).set("Content-Type", "application/json").send("{");
  assert.equal(malformed.status, 400);
  assert.equal(malformed.body.error, "Malformed JSON request body.");
  const oversized = await request(app).post("/api/v1/auth/login").set("Origin", origin).set("Content-Type", "application/json").send(JSON.stringify({ email: "admin@campus.example", password: "x".repeat(40_000) }));
  assert.equal(oversized.status, 413);
  const unknown = await request(app).get("/api/v1/does-not-exist");
  assert.equal(unknown.status, 404);
  assert.deepEqual(unknown.body, { error: "Not found." });
});

test("login rate limiting bounds repeated password attempts", async () => {
  const app = createApp(new MemoryStore(), config());
  for (let attempt = 0; attempt < 8; attempt += 1) {
    const response = await request(app).post("/api/v1/auth/login").set("Origin", origin).send({ email: "admin@campus.example", password: "incorrect password example" });
    assert.equal(response.status, 401);
  }
  const limited = await request(app).post("/api/v1/auth/login").set("Origin", origin).send({ email: "admin@campus.example", password: "incorrect password example" });
  assert.equal(limited.status, 429);
});

test("logout invalidates the server session and clears both cookies", async () => {
  const agent = request.agent(createApp(new MemoryStore(), config()));
  const csrf = await login(agent);
  assert.equal((await agent.get("/api/v1/admin/notices")).status, 200);
  const logout = await agent.post("/api/v1/auth/logout").set("Origin", origin).set("X-CSRF-Token", csrf);
  assert.equal(logout.status, 204);
  assert.equal((await agent.get("/api/v1/admin/notices")).status, 401);
  const cleared = logout.headers["set-cookie"] as unknown as string[];
  assert.equal(cleared.filter((value) => /portal_(?:session|csrf)=;/.test(value)).length, 2);
});

test("logout is idempotent after a session expires but still protects a live session with CSRF", async () => {
  const store = new MemoryStore();
  const app = createApp(store, config());
  const missing = await request(app).post("/api/v1/auth/logout").set("Origin", origin);
  assert.equal(missing.status, 204);

  const user = store.users.get("admin@campus.example")!;
  store.sessions.set(sha256("expired-logout"), { user: { id: user.id, email: user.email, displayName: user.displayName, roles: user.roles }, csrfHash: sha256("expired-csrf"), expiresAt: new Date(Date.now() - 1) });
  const expired = await request(app).post("/api/v1/auth/logout").set("Origin", origin).set("Cookie", "portal_session=expired-logout");
  assert.equal(expired.status, 204);

  const agent = request.agent(app);
  await login(agent);
  const protectedLogout = await agent.post("/api/v1/auth/logout").set("Origin", origin).set("X-CSRF-Token", "wrong-token");
  assert.equal(protectedLogout.status, 403);
});

test("validated admin CRUD records an audit event without request bodies", async () => {
  const store = new MemoryStore();
  const agent = request.agent(createApp(store, config()));
  const csrf = await login(agent);
  const unsafe = await agent.post("/api/v1/admin/feedbackForms").set("Origin", origin).set("X-CSRF-Token", csrf).send({ name: "Unsafe", url: "javascript:alert(1)", visible: true });
  assert.equal(unsafe.status, 400);
  const massAssignment = await agent.post("/api/v1/admin/feedbackForms").set("Origin", origin).set("X-CSRF-Token", csrf).send({ name: "Extra field", url: "https://forms.example/extra", visible: true, responses: ["must not be stored"] });
  assert.equal(massAssignment.status, 400);

  const created = await agent.post("/api/v1/admin/feedbackForms").set("Origin", origin).set("X-CSRF-Token", csrf).send({ name: "General feedback", url: "https://forms.example/general", visible: true });
  assert.equal(created.status, 201);
  assert.equal(store.audits[0]?.action, "create");
  assert.deepEqual(Object.keys(store.audits[0]!).sort(), ["action", "actorUserId", "entityId", "entityType", "requestId"]);
  assert.equal(JSON.stringify(store.audits[0]).includes("forms.example"), false);

  const session = await agent.get("/api/v1/auth/session");
  assert.equal(session.body.user.roles.includes("content_admin"), true);
  assert.equal(typeof session.body.csrfToken, "string");
  assert.equal(session.headers["cache-control"], "no-store");

  const injectionShaped = await agent.post("/api/v1/admin/resources").set("Origin", origin).set("X-CSRF-Token", csrf).send({ title: "<script>alert(1)</script>", description: "Example'); DROP TABLE resources; --", category: "Test", url: "", visible: true });
  assert.equal(injectionShaped.status, 201);
  assert.equal(injectionShaped.body.title, "<script>alert(1)</script>");
  assert.equal(store.audits.some((event) => JSON.stringify(event).includes("DROP TABLE")), false);

  const updated = await agent.put(`/api/v1/admin/feedbackForms/${created.body.id}`).set("Origin", origin).set("X-CSRF-Token", csrf).send({ name: "General feedback", url: "https://forms.example/general", visible: false });
  assert.equal(updated.status, 200);
  assert.equal(updated.body.visible, false);
  assert.equal(store.audits[2]?.action, "update");

  const duplicateUpdate = await agent.put(`/api/v1/admin/feedbackForms/${created.body.id}`).set("Origin", origin).set("X-CSRF-Token", csrf).send({ name: "General feedback", url: "https://forms.example/general", visible: false });
  assert.equal(duplicateUpdate.status, 200);
  assert.equal((await store.list("feedbackForms")).length, 1);

  const auditList = await agent.get("/api/v1/admin/audit-events");
  assert.equal(auditList.status, 200);
  assert.equal(auditList.body.length, 4);

  const auditPage = await agent.get("/api/v1/admin/audit-events?limit=2&offset=1");
  assert.equal(auditPage.status, 200);
  assert.deepEqual(auditPage.body, store.audits.slice().reverse().slice(1, 3));
  for (const query of ["limit=0", "limit=101", "limit=1.5", "offset=-1", "offset=10001"]) {
    const invalidPage = await agent.get(`/api/v1/admin/audit-events?${query}`);
    assert.equal(invalidPage.status, 400);
    assert.equal(invalidPage.body.error, "Invalid audit pagination.");
  }

  const invalidId = await agent.put("/api/v1/admin/feedbackForms/not-a-uuid").set("Origin", origin).set("X-CSRF-Token", csrf).send({ name: "General feedback", url: "https://forms.example/general", visible: false });
  assert.equal(invalidId.status, 400);

  const deleted = await agent.delete(`/api/v1/admin/feedbackForms/${created.body.id}`).set("Origin", origin).set("X-CSRF-Token", csrf);
  assert.equal(deleted.status, 204);
  assert.equal(store.audits[4]?.action, "delete");
});

test("secure session cookie flags are set when secure cookies are configured", async () => {
  const response = await request(createApp(new MemoryStore(), { ...config(), secureCookie: true })).post("/api/v1/auth/login").set("Origin", origin).send({ email: "admin@campus.example", password });
  assert.equal(response.status, 200);
  const cookies = response.headers["set-cookie"] as unknown as string[];
  const session = cookies.find((value) => value.startsWith("portal_session=")) ?? "";
  const csrf = cookies.find((value) => value.startsWith("portal_csrf=")) ?? "";
  assert.match(session, /HttpOnly/); assert.match(session, /Secure/); assert.match(session, /SameSite=Lax/);
  assert.doesNotMatch(csrf, /HttpOnly/); assert.match(csrf, /Secure/); assert.match(csrf, /SameSite=Strict/);
});
