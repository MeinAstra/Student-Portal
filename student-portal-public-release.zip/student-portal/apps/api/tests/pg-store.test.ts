import assert from "node:assert/strict";
import test from "node:test";
import type { Pool } from "pg";
import { migrate, PgStore } from "../src/pg-store.js";

test("an audit insertion failure rolls back its content mutation", async () => {
  const queries: string[] = [];
  let pendingRecord = false;
  let committedRecord = false;
  let released = false;
  const client = {
    async query(sql: string) {
      queries.push(sql);
      if (sql === "BEGIN") return { rows: [], rowCount: null };
      if (sql.startsWith("INSERT INTO feedback_forms")) {
        pendingRecord = true;
        return { rows: [{ id: "20000000-0000-4000-8000-000000000001", name: "Example", url: "https://forms.example/", visible: true }], rowCount: 1 };
      }
      if (sql.startsWith("INSERT INTO audit_events")) throw new Error("simulated audit failure");
      if (sql === "COMMIT") { committedRecord = pendingRecord; return { rows: [], rowCount: null }; }
      if (sql === "ROLLBACK") { pendingRecord = false; return { rows: [], rowCount: null }; }
      throw new Error(`Unexpected query: ${sql}`);
    },
    release() { released = true; }
  };
  const pool = { async connect() { return client; }, async end() {} } as unknown as Pool;
  const store = new PgStore("postgresql://test.example/database", pool);
  await assert.rejects(
    store.create("feedbackForms", { name: "Example", url: "https://forms.example/", visible: true }, { actorUserId: "10000000-0000-4000-8000-000000000001", action: "create", entityType: "feedbackForms", requestId: "30000000-0000-4000-8000-000000000001" }),
    /simulated audit failure/
  );
  assert.equal(committedRecord, false);
  assert.equal(pendingRecord, false);
  assert.equal(queries.includes("ROLLBACK"), true);
  assert.equal(queries.includes("COMMIT"), false);
  assert.equal(released, true);
});

test("Admin campus-map reads include hidden settings", async () => {
  const hidden = { title: "Hidden map", visible: false };
  let sql = "";
  const pool = { async query(query: string) { sql = query; return { rows: [hidden] }; } } as unknown as Pool;
  assert.deepEqual(await new PgStore("postgresql://test.example/database", pool).adminCampusMap(), hidden);
  assert.match(sql, /FROM campus_map/);
  assert.doesNotMatch(sql, /WHERE visible/);
});

test("migration acquisition and release use the same advisory-lock key", async () => {
  const lockParameters: unknown[][] = [];
  let released = false;
  const client = {
    async query(sql: string, parameters: unknown[] = []) {
      if (sql.includes("pg_advisory_")) lockParameters.push(parameters);
      if (sql.startsWith("SELECT 1 FROM schema_migrations")) return { rows: [{ exists: 1 }], rowCount: 1 };
      return { rows: [], rowCount: null };
    },
    release() { released = true; }
  };
  const pool = { async connect() { return client; }, async end() {} } as unknown as Pool;
  await migrate(new PgStore("postgresql://test.example/database", pool));
  assert.equal(lockParameters.length, 2);
  assert.deepEqual(lockParameters[0], lockParameters[1]);
  assert.equal(released, true);
});

test("readiness requires the initial schema migration", async () => {
  const pool = { async query() { return { rows: [{ ready: false }], rowCount: 1 }; }, async end() {} } as unknown as Pool;
  await assert.rejects(new PgStore("postgresql://test.example/database", pool).readiness(), /migration/i);
});

test("audit history uses parameterized limit and offset pagination", async () => {
  let capturedSql = "";
  let capturedParameters: unknown[] = [];
  const pool = {
    async query(sql: string, parameters: unknown[]) {
      capturedSql = sql;
      capturedParameters = parameters;
      return { rows: [], rowCount: 0 };
    },
    async end() {}
  } as unknown as Pool;
  await new PgStore("postgresql://test.example/database", pool).listAuditEvents(25, 50);
  assert.match(capturedSql, /LIMIT \$1 OFFSET \$2/);
  assert.deepEqual(capturedParameters, [25, 50]);
});

test("account replacement revokes sessions atomically", async () => {
  const queries: Array<{ sql: string; values: unknown[] }> = [];
  const userId = "10000000-0000-4000-8000-000000000001";
  let failRoles = false;
  const client = {
    async query(sql: string, values: unknown[] = []) {
      queries.push({ sql, values });
      if (failRoles && sql.startsWith("INSERT INTO user_roles")) throw new Error("role write failed");
      return { rows: [{ id: userId }], rowCount: 1 };
    },
    release() {}
  };
  const store = new PgStore("postgresql://test.example/database", { async connect() { return client; } } as unknown as Pool);
  const input = { email: "admin@example.com", displayName: "Example", passwordHash: "test-only-placeholder", roles: ["content_admin" as const] };
  await store.createUser(input);
  const revoke = queries.findIndex(({ sql }) => sql === "DELETE FROM sessions WHERE user_id = $1");
  assert.ok(revoke > 0);
  assert.deepEqual(queries[revoke]!.values, [userId]);
  assert.equal(queries[0]!.sql, "BEGIN");
  assert.equal(queries.at(-1)!.sql, "COMMIT");
  queries.length = 0;
  failRoles = true;
  await assert.rejects(store.createUser(input), /role write failed/);
  assert.equal(queries.at(-1)!.sql, "ROLLBACK");
  assert.equal(queries.some(({ sql }) => sql === "COMMIT"), false);
});
