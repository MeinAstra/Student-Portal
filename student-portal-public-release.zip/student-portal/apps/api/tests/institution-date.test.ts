import assert from "node:assert/strict";
import test from "node:test";
import { institutionDate } from "../src/institution-date.js";

test("institutionDate crosses midnight according to the institution time zone", () => {
  assert.equal(institutionDate(new Date("2026-08-29T15:59:59.000Z"), "Asia/Shanghai"), "2026-08-29");
  assert.equal(institutionDate(new Date("2026-08-29T16:00:00.000Z"), "Asia/Shanghai"), "2026-08-30");
});

test("institutionDate follows daylight-saving transitions without server-local assumptions", () => {
  assert.equal(institutionDate(new Date("2026-03-08T04:30:00.000Z"), "America/New_York"), "2026-03-07");
  assert.equal(institutionDate(new Date("2026-03-08T07:30:00.000Z"), "America/New_York"), "2026-03-08");
});
