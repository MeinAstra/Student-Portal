import assert from "node:assert/strict";
import test from "node:test";
import type { Pool } from "pg";
import { seed, validateResetTarget } from "../src/cli.js";
import { loadConfig } from "../src/config.js";
import { PgStore } from "../src/pg-store.js";

function fakeStore() {
  const queries: string[] = [];
  const parameters: unknown[][] = [];
  let released = false;
  const client = {
    async query(sql: string, values: unknown[] = []) { queries.push(sql); parameters.push(values); return { rows: [], rowCount: null }; },
    release() { released = true; }
  };
  const pool = { async connect() { return client; }, async end() {} } as unknown as Pool;
  return { store: new PgStore("postgresql://test.example/database", pool), queries, parameters, released: () => released };
}

test("normal seeding is idempotent and does not truncate existing demo content", async () => {
  const fake = fakeStore();
  await seed(fake.store, false);
  assert.equal(fake.queries.some((query) => query.startsWith("TRUNCATE")), false);
  assert.equal(fake.queries.filter((query) => query.includes("ON CONFLICT")).length >= 7, true);
  assert.equal(fake.queries.at(0), "BEGIN");
  assert.equal(fake.queries.at(1), "SELECT set_config('TimeZone', $1, true)");
  assert.equal(fake.queries.at(-1), "COMMIT");
  assert.equal(fake.released(), true);
});

test("reset requires a confirmed dedicated loopback database and rejects URL overrides", () => {
  const config = loadConfig({ PORTAL_WRITE_MODE: "local", DATABASE_URL: "postgresql://127.0.0.1:5432/student_portal_demo" });
  assert.equal(validateResetTarget(config, "--confirm-reset=student_portal_demo"), "student_portal_demo");
  assert.equal(validateResetTarget({ ...config, databaseUrl: "postgresql://[::1]/student_portal_demo_test" }, "--confirm-reset=student_portal_demo_test"), "student_portal_demo_test");
  for (const url of [
    "postgresql://remote.example/student_portal_demo", "postgresql://localhost/student_portal_demo",
    "postgresql://127.0.0.1/other", "postgresql://127.0.0.1:5433/student_portal_demo",
    "postgresql://127.0.0.1/student_portal_demo?host=remote.example",
    "postgresql://127.0.0.1/student_portal_demo#override", "invalid"
  ]) assert.throws(() => validateResetTarget({ ...config, databaseUrl: url }, "--confirm-reset=student_portal_demo"), /Reset requires/);
  for (const confirmation of [undefined, "--confirm-reset=other"]) assert.throws(() => validateResetTarget(config, confirmation), /Reset requires/);
  assert.throws(() => validateResetTarget({ ...config, writeMode: "readonly" }, "--confirm-reset=student_portal_demo"), /Reset requires/);
});

test("local reset clears all mutable content, sessions, and audits while preserving users", async () => {
  const fake = fakeStore();
  await seed(fake.store, true);
  const reset = fake.queries.find((query) => query.startsWith("TRUNCATE")) ?? "";
  for (const table of ["sessions", "audit_events", "feedback_forms", "asset_metadata", "support_contacts", "notices", "portal_status"]) assert.match(reset, new RegExp(`\\b${table}\\b`));
  assert.doesNotMatch(reset, /\bportal_users\b/);
  assert.doesNotMatch(reset, /\buser_roles\b/);
});

test("seeded Demo School support content stays inside the draft directory boundary", async () => {
  const fake = fakeStore();
  await seed(fake.store, false);
  const support = fake.queries.find((query) => query.includes("INSERT INTO support_contacts")) ?? "";
  assert.match(support, /'health_emergency'/);
  assert.match(support, /'wellbeing'/);
  assert.match(support, /'community_safety'/);
  assert.match(support, /STAFF CONTENT APPROVAL REQUIRED/);
  assert.doesNotMatch(support, /\b(?:CPR|anaphylaxis|epinephrine|dispatcher|diagnosis|treatment)\b/i);
  assert.match(support, /not a reporting route or safeguarding workflow/i);
});

test("seed date expressions run under the configured institution time zone", async () => {
  const fake = fakeStore();
  await seed(fake.store, false, "America/New_York");
  assert.equal(fake.queries.includes("SELECT set_config('TimeZone', $1, true)"), true);
  assert.deepEqual(fake.parameters[1], ["America/New_York"]);
});
