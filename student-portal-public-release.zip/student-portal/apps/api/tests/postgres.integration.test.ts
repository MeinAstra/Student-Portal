import assert from "node:assert/strict";
import { randomBytes, randomUUID } from "node:crypto";
import test from "node:test";
import request from "supertest";
import { createApp } from "../src/app.js";
import { institutionDate } from "../src/institution-date.js";
import { migrate, PgStore } from "../src/pg-store.js";
import { hashPassword } from "../src/security.js";

const databaseUrl = process.env.PORTAL_TEST_DATABASE_URL;
const isIsolatedTestDatabase = databaseUrl ? new URL(databaseUrl).pathname.endsWith("_test") : false;
const origin = "http://localhost:5174";

function dateFromToday(offset: number) {
  const date = new Date(`${institutionDate(new Date(), "Asia/Shanghai")}T00:00:00.000Z`);
  date.setUTCDate(date.getUTCDate() + offset);
  return date.toISOString().slice(0, 10);
}

test("PostgreSQL enforces visibility, expiry, and parameterized content storage", { skip: !isIsolatedTestDatabase }, async () => {
  const store = new PgStore(databaseUrl!);
  await migrate(store);
  const password = randomBytes(24).toString("base64url");
  await store.createUser({ email: "admin@integration.example", displayName: "Integration Admin Example", passwordHash: hashPassword(password), roles: ["viewer", "content_admin"] });
  const app = createApp(store, { databaseUrl: databaseUrl!, host: "127.0.0.1", port: 3000, writeMode: "local", secureCookie: false, allowedOrigin: origin, institutionTimeZone: "Asia/Shanghai", nodeEnv: "test" });
  const agent = request.agent(app);
  const login = await agent.post("/api/v1/auth/login").set("Origin", origin).send({ email: "admin@integration.example", password });
  assert.equal(login.status, 200);
  const csrf = login.body.csrfToken as string;
  const hiddenMap = { title: "Hidden integration map", description: "Fictional map", imageUrl: "", visible: false };
  assert.equal((await agent.put("/api/v1/admin/singletons/campusMap").set("Origin", origin)
    .set("X-CSRF-Token", csrf).send(hiddenMap)).status, 200);
  assert.equal((await agent.get("/api/v1/content")).body.campusMap, null);
  const adminMap = await agent.get("/api/v1/admin/singletons/campusMap");
  assert.equal(adminMap.status, 200);
  assert.equal(adminMap.body.title, hiddenMap.title);
  assert.equal(adminMap.body.visible, false);
  const marker = randomUUID().slice(0, 8);

  const notices = [
    { title: `Visible ${marker}`, summary: "Current fictional content.", category: "Test", publishDate: dateFromToday(-1), expiryDate: dateFromToday(1), imageUrl: "", visible: true },
    { title: `Hidden ${marker}`, summary: "Hidden fictional content.", category: "Test", publishDate: dateFromToday(-1), expiryDate: dateFromToday(1), imageUrl: "", visible: false },
    { title: `Expired ${marker}`, summary: "Expired fictional content.", category: "Test", publishDate: dateFromToday(-2), expiryDate: dateFromToday(-1), imageUrl: "", visible: true }
  ];
  for (const notice of notices) {
    const response = await agent.post("/api/v1/admin/notices").set("Origin", origin).set("X-CSRF-Token", csrf).send(notice);
    assert.equal(response.status, 201);
  }

  const shapedTitle = `Example ${marker}'); DROP TABLE resources; --`;
  const sqlShaped = await agent.post("/api/v1/admin/resources").set("Origin", origin).set("X-CSRF-Token", csrf).send({ title: shapedTitle, description: "Stored as plain content.", category: "Test", url: "", visible: true });
  assert.equal(sqlShaped.status, 201);
  const publicContent = await agent.get("/api/v1/content");
  const titles = publicContent.body.notices.map((item: { title: string }) => item.title) as string[];
  assert.equal(titles.includes(`Visible ${marker}`), true);
  assert.equal(titles.includes(`Hidden ${marker}`), false);
  assert.equal(titles.includes(`Expired ${marker}`), false);
  assert.equal(publicContent.body.resources.some((item: { title: string }) => item.title === shapedTitle), true);
  await store.createUser({ email: "admin@integration.example", displayName: "Integration Admin Example", passwordHash: hashPassword(password), roles: ["viewer", "content_admin"] });
  const revoked = await agent.get("/api/v1/admin/notices");
  assert.equal(revoked.status, 401);
  const sessionCount = await store.pool.query("SELECT count(*)::int AS count FROM sessions s JOIN portal_users u ON u.id = s.user_id WHERE u.email = $1", ["admin@integration.example"]);
  assert.equal(sessionCount.rows[0].count, 0);
  await store.close();

  const reopened = new PgStore(databaseUrl!);
  await reopened.readiness();
  const persisted = await reopened.publicContent(institutionDate(new Date(), "Asia/Shanghai"));
  assert.equal(persisted.resources.some((item) => item.title === shapedTitle), true);
  const audits = await reopened.listAuditEvents(100, 0);
  assert.equal(audits.some((event) => (event as { entityId?: string }).entityId === sqlShaped.body.id), true);
  const auditPage = await reopened.listAuditEvents(2, 1);
  assert.equal(auditPage.length, 2);
  assert.deepEqual(auditPage, audits.slice(1, 3));
  await reopened.close();
});
