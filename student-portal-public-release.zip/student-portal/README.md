# Student Portal

A completed high-school software engineering and portfolio project demonstrating a full-stack portal for a fictional campus. It is an educational prototype, not a deployed school service or a production-ready product.

> This project is not affiliated with or endorsed by any school or educational institution. All people, accounts, records, announcements, schedules, and operational content are fictional or demonstrative. Content is for demonstration only and does not constitute administrative, medical, legal, safeguarding, or other professional advice.

## What it demonstrates

- Public notices with publication/expiry filtering, upcoming events, a fictional contact directory, resource links and map metadata.
- Placeholder-only Health, Well-being and Community Safety directories.
- Local Admin create/edit/hide/delete workflows, map/status settings and paginated audit history.
- Fictional local accounts, server-side roles and expiring sessions.
- PostgreSQL persistence, versioned migrations and transactional content/audit writes.
- Shared validation contracts, automated tests and CI.

Feedback features store form names and links only; they do not collect responses. Assets are URL metadata, not uploaded files. No school identity provider, real student records or live institutional integration is included.

## Stack and architecture

React 19, React Router 7 and Vite 7 form the TypeScript frontend. An Express 5 API runs on Node.js, uses Zod 4 contracts shared with the frontend, and stores data in PostgreSQL 17 through `pg`. npm workspaces organize this modular monolith:

```text
Browser → React/Vite → Express REST API → PostgreSQL
                      ↕
                Shared Zod contracts
```

There are no microservices or external infrastructure requirements beyond the local database.

## Run locally

Prerequisites: Node.js **22.13+ within 22.x, or 24.x**, npm, and Docker with Compose. Optional interactive account creation requires Bash on macOS/Linux; Windows account setup is unverified.

From the extracted project root:

```sh
npm ci
npm run env:init
docker compose up -d --wait postgres
npm run db:migrate
npm run db:seed
npm run dev
```

Open **http://localhost:5174**. Keep the process terminal open.

| Service | Local address |
|---|---|
| Frontend | `http://localhost:5174` |
| API | `http://127.0.0.1:3000` |
| PostgreSQL | `127.0.0.1:5432` |

The frontend uses a strict port: it fails instead of silently selecting another port. Its API proxy targets port 3000; changing the API's `PORT` alone does not update that proxy. Do not stop another project's process to make room without identifying it first.

`env:init` creates an ignored, private `.env` and generates local database credentials without printing them. It refuses to overwrite an existing file. The shipped `.env.example` contains placeholders, not usable credentials. The initializer enables local Admin mode; the API otherwise defaults to read-only and rejects writable production mode.

For optional Admin testing, run `npm run demo:user` in a separate terminal, use a reserved example-domain email, and choose a password through its hidden prompt. No account or password is shipped. Recreating the same fictional account replaces its password/roles and revokes existing sessions. Public browsing does not require an account.

The database defaults to `student_portal_demo`. This public edition is a fresh demo setup, not a migration of any previous review database. Do not reuse another project's environment file or volume.

## Check, stop and reset

```sh
curl --noproxy '*' http://127.0.0.1:3000/api/v1/health/live
curl --noproxy '*' http://127.0.0.1:3000/api/v1/health/ready
npm run verify
npm run audit
```

Liveness checks the API process; readiness checks the database and required schema independently of cookies. API startup refuses to listen until the database is ready.

To stop, press Ctrl+C in application terminals, then run `docker compose stop postgres`. This preserves data. See [the local operations guide](README-FIRST.md) for troubleshooting and the explicitly destructive reset command.

Seeds are date-relative upserts: rerunning seed overwrites seeded fields on canonical demo records while preserving additional records. Dates use `INSTITUTION_TIME_ZONE` (default `Asia/Shanghai` as a demonstration timezone). Migrations are forward-only; rollback migrations are not provided.

## Security controls and limits

Implemented controls include server-side Admin authorization, exact-Origin checks, per-session CSRF checks on mutations, salted scrypt password hashes, hashed session tokens, HttpOnly/SameSite cookies, strict request validation, parameterized SQL, atomic audit writes, rate limits, bounded JSON bodies and security headers. Auth/Admin responses are non-cacheable. Request logs use request IDs and route templates rather than raw paths or exception messages. See [SECURITY.md](SECURITY.md).

These are implementation controls, not a security certification. Production identity, hosting, TLS, operational monitoring, backup/recovery, retention, approved content and accessibility acceptance are outside the completed project's scope. Rate limits are process-local; concurrent edits are last-writer-wins; audit pagination is not a snapshot. The local database account is a demo bootstrap account, not a production minimum-privilege design.

Never enter real student, medical, counseling, safeguarding, disciplinary or other private records. HTTPS links can still lead to third-party sites; demonstration links use reserved example domains.

## Verification status

`npm run verify` runs lint, typechecking, contract/API/frontend tests, production builds and safety/metadata checks. The PostgreSQL integration test only runs when `PORTAL_TEST_DATABASE_URL` points to a separate disposable database ending in `_test`; otherwise it is explicitly skipped. CI is configured to run it on PostgreSQL 17.

The publication build's automated results and unavailable runtime checks are recorded in [VERIFICATION.md](VERIFICATION.md). Manual browser review is separate from source/render tests. Pre-Git exports report Git metadata inspection as not applicable, not as clean history. No scanner guarantees absence of all secrets.

## Project layout

- `apps/web`: frontend and local Admin UI
- `apps/api`: API, database store, migrations and API tests
- `packages/contracts`: shared schemas and types
- `scripts`: local environment setup and safety checks
- `docker-compose.yml`: local PostgreSQL only
- `.github/workflows/ci.yml`: automated verification
- [ARCHITECTURE.md](ARCHITECTURE.md): implementation boundaries

## License

Project code is distributed under the [MIT License](LICENSE), preserving the repository's copyright notice. Third-party dependencies retain their own licenses; see [THIRD-PARTY-NOTICES.md](THIRD-PARTY-NOTICES.md).
