# Third-party materials

The root MIT License applies to project-authored code, not to third-party dependencies. npm installs dependencies separately; their copyright notices and licenses remain in their respective packages. The lockfile records resolved versions and declared license identifiers.

No third-party photographs, school documents, downloaded fonts, icon packs or binary map assets are bundled. The interface uses CSS, text and system fonts; the map is a fictional placeholder. User-configured external images/links are not supplied assets and require independent permission before redistribution or real use.

Dependency metadata includes MIT, ISC, Apache-2.0, BSD, BlueOak-1.0.0, 0BSD and CC-BY-4.0 declarations. This is a metadata review, not a comprehensive legal provenance audit. Preserve dependency notices if distributing installed dependencies or generated bundles separately.
