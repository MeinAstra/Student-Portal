# Architecture

## Modular monolith

The review edition has three code boundaries in one deployable application shape:

1. `apps/web`: React/Vite interface and local Admin CMS.
2. `apps/api`: Express REST API, authentication, authorization, validation, PostgreSQL persistence, and audit events.
3. `packages/contracts`: shared Zod request schemas and TypeScript contracts.

There are no microservices, queues, distributed caches, GraphQL, cloud-provider components, or host-network dependencies.

## Trust boundaries

- The browser is untrusted. Client route guards and displayed roles are UX only.
- The API validates the server-managed session and `content_admin` role on every Admin operation.
- All unsafe requests require an exact allowed Origin. Admin mutations and active-session logout also require the per-session CSRF token; login does not require an existing session.
- Zod rejects unknown fields and invalid values before parameterized PostgreSQL queries run.
- Database constraints independently protect formats, visibility, date ordering, identities, session hashes, and audit-event types.
- A content mutation and its audit event share one transaction and roll back together.
- Public queries enforce visibility and notice date/expiry rules on the server. Authorized local Admins load map settings through `GET /api/v1/admin/singletons/campusMap`, including hidden values; this does not change public filtering.
- External metadata URLs require HTTPS and reject embedded usernames/passwords.

## Data boundary

The database stores service-directory and publishing content. It has no tables or API models for student profiles, medical records, counseling notes, safeguarding cases, incident reports, disciplinary records, feedback responses, chat histories, or private staff notes.

Feedback Forms remain external. Only `name`, HTTPS `url`, and `visible` metadata are stored. The portal does not use a Forms API or receive, proxy, analyze, or retain responses.

Publication dates are calendar dates, not instants. The API derives one date from `INSTITUTION_TIME_ZONE` and passes it to all notice, expiry, and upcoming-event queries. Seed transactions set the same PostgreSQL session timezone before evaluating date-relative demo data.

Liveness and readiness are separate trust signals. Liveness proves only that the API process responds; readiness additionally verifies the PostgreSQL connection and required initial migration. The API does not listen at startup until that readiness check passes.

## Production replacement points

Any real deployment would require its operator to choose and implement identity, managed database, secrets, hosting, TLS, monitoring, backups, retention, asset storage, approved external domains, and operational ownership. The review code contains no tenant, production credential, internal hostname, network topology, or live integration assumption.
